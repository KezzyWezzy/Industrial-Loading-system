# backend/app/modules/reporting/csv_handler.py
import csv
import pandas as pd
import io
from typing import Dict, List, Any, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class CSVHandler:
    
    @staticmethod
    async def export_transactions(transactions: List[Dict[str, Any]], output_path: str) -> bool:
        """Export transactions to CSV"""
        try:
            df = pd.DataFrame(transactions)
            
            # Reorder columns
            column_order = [
                'transaction_id', 'date', 'time', 'bol_number', 'product',
                'source_tank', 'loading_bay', 'vehicle_id', 'driver_name',
                'carrier', 'gross_volume', 'net_volume', 'temperature',
                'gross_weight', 'tare_weight', 'net_weight', 'status'
            ]
            
            # Only include columns that exist
            columns = [col for col in column_order if col in df.columns]
            df = df[columns]
            
            # Format dates and numbers
            if 'date' in df.columns:
                df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
            if 'time' in df.columns:
                df['time'] = pd.to_datetime(df['time']).dt.strftime('%H:%M:%S')
            
            # Round numeric columns
            numeric_columns = ['gross_volume', 'net_volume', 'temperature', 
                             'gross_weight', 'tare_weight', 'net_weight']
            for col in numeric_columns:
                if col in df.columns:
                    df[col] = df[col].round(2)
            
            # Export to CSV
            df.to_csv(output_path, index=False)
            logger.info(f"Exported {len(transactions)} transactions to {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting transactions to CSV: {e}")
            return False
    
    @staticmethod
    async def export_inventory(inventory_data: List[Dict[str, Any]], output_path: str) -> bool:
        """Export tank inventory to CSV"""
        try:
            df = pd.DataFrame(inventory_data)
            
            # Format columns
            column_mapping = {
                'tank_number': 'Tank #',
                'product': 'Product',
                'current_level': 'Level (ft)',
                'current_volume': 'Volume (BBL)',
                'temperature': 'Temp (°F)',
                'available_capacity': 'Available (BBL)',
                'utilization': 'Utilization %',
                'last_gauged': 'Last Gauged'
            }
            
            df = df.rename(columns=column_mapping)
            
            # Format numbers
            numeric_columns = ['Level (ft)', 'Volume (BBL)', 'Temp (°F)', 
                             'Available (BBL)', 'Utilization %']
            for col in numeric_columns:
                if col in df.columns:
                    df[col] = df[col].round(2)
            
            # Export to CSV
            df.to_csv(output_path, index=False)
            logger.info(f"Exported inventory for {len(inventory_data)} tanks to {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting inventory to CSV: {e}")
            return False
    
    @staticmethod
    async def import_tank_data(file_path: str) -> Optional[List[Dict[str, Any]]]:
        """Import tank data from CSV"""
        try:
            df = pd.read_csv(file_path)
            
            # Validate required columns
            required_columns = ['tank_number', 'capacity', 'product']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                logger.error(f"Missing required columns: {missing_columns}")
                return None
            
            # Clean and validate data
            df['tank_number'] = df['tank_number'].astype(str).str.strip()
            df['capacity'] = pd.to_numeric(df['capacity'], errors='coerce')
            df['product'] = df['product'].astype(str).str.strip()
            
            # Remove invalid rows
            df = df.dropna(subset=required_columns)
            
            # Convert to list of dictionaries
            tank_data = df.to_dict('records')
            
            logger.info(f"Imported {len(tank_data)} tanks from {file_path}")
            return tank_data
            
        except Exception as e:
            logger.error(f"Error importing tank data from CSV: {e}")
            return None
    
    @staticmethod
    async def bulk_export(data_sets: Dict[str, List[Dict[str, Any]]], output_path: str) -> bool:
        """Export multiple data sets to Excel file with multiple sheets"""
        try:
            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                for sheet_name, data in data_sets.items():
                    if data:
                        df = pd.DataFrame(data)
                        df.to_excel(writer, sheet_name=sheet_name[:31], index=False)  # Excel sheet name limit
                        
                        # Auto-adjust column widths
                        worksheet = writer.sheets[sheet_name[:31]]
                        for column in df:
                            column_length = max(df[column].astype(str).map(len).max(), len(str(column)))
                            col_idx = df.columns.get_loc(column)
                            worksheet.column_dimensions[chr(65 + col_idx)].width = min(column_length + 2, 50)
            
            logger.info(f"Exported {len(data_sets)} data sets to {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error in bulk export: {e}")
            return False