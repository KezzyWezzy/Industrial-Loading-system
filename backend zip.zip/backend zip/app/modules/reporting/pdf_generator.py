# backend/app/modules/reporting/pdf_generator.py
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.linecharts import HorizontalLineChart
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.piecharts import Pie
import io
import os
from typing import Dict, List, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class PDFGenerator:
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1a237e'),
            spaceAfter=30,
            alignment=TA_CENTER
        ))
        
        self.styles.add(ParagraphStyle(
            name='CustomHeading',
            parent=self.styles['Heading2'],
            fontSize=16,
            textColor=colors.HexColor('#3949ab'),
            spaceAfter=12
        ))
        
        self.styles.add(ParagraphStyle(
            name='InfoText',
            parent=self.styles['Normal'],
            fontSize=10,
            leading=14
        ))
    
    async def generate_custody_transfer_report(self, data: Dict[str, Any], output_path: str) -> bool:
        """Generate custody transfer report PDF"""
        try:
            doc = SimpleDocTemplate(
                output_path,
                pagesize=letter,
                rightMargin=72,
                leftMargin=72,
                topMargin=72,
                bottomMargin=18
            )
            
            story = []
            
            # Title
            story.append(Paragraph("CUSTODY TRANSFER REPORT", self.styles['CustomTitle']))
            story.append(Spacer(1, 0.2*inch))
            
            # Report Information
            info_data = [
                ['Report Date:', datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')],
                ['Period:', f"{data['start_date']} to {data['end_date']}"],
                ['Facility:', data.get('facility_name', 'All Facilities')],
                ['Total Transfers:', str(data.get('total_transfers', 0))]
            ]
            
            info_table = Table(info_data, colWidths=[2*inch, 4*inch])
            info_table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
                ('ALIGN', (1, 0), (1, -1), 'LEFT'),
            ]))
            
            story.append(info_table)
            story.append(Spacer(1, 0.5*inch))
            
            # Summary Statistics
            story.append(Paragraph("Summary Statistics", self.styles['CustomHeading']))
            
            summary_data = [
                ['Product', 'Transfers', 'Total Volume (BBL)', 'Avg Volume (BBL)'],
            ]
            
            for product in data.get('product_summary', []):
                summary_data.append([
                    product['product_name'],
                    str(product['transfer_count']),
                    f"{product['total_volume']:,.2f}",
                    f"{product['avg_volume']:,.2f}"
                ])
            
            summary_table = Table(summary_data, colWidths=[2*inch, 1.5*inch, 2*inch, 1.5*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(summary_table)
            story.append(Spacer(1, 0.5*inch))
            
            # Detailed Transfers
            story.append(PageBreak())
            story.append(Paragraph("Detailed Transfer Records", self.styles['CustomHeading']))
            
            # Create detailed transfer table
            detail_headers = [
                'Date/Time', 'BOL #', 'Product', 'Source', 'Destination', 
                'Volume (BBL)', 'Driver', 'Carrier'
            ]
            
            detail_data = [detail_headers]
            
            for transfer in data.get('transfers', []):
                detail_data.append([
                    transfer['datetime'],
                    transfer['bol_number'],
                    transfer['product'],
                    transfer['source'],
                    transfer['destination'],
                    f"{transfer['volume']:,.2f}",
                    transfer['driver'],
                    transfer['carrier']
                ])
            
            # Split into pages if too many rows
            rows_per_page = 40
            for i in range(0, len(detail_data), rows_per_page):
                if i > 0:
                    story.append(PageBreak())
                    story.append(Paragraph("Detailed Transfer Records (continued)", self.styles['CustomHeading']))
                
                page_data = detail_data[i:i+rows_per_page]
                if i > 0:
                    page_data.insert(0, detail_headers)  # Re-add headers
                
                detail_table = Table(page_data, repeatRows=1)
                detail_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 8),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                    ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey])
                ]))
                
                story.append(detail_table)
            
            # Build PDF
            doc.build(story)
            logger.info(f"Custody transfer report generated: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error generating custody transfer report: {e}")
            return False
    
    async def generate_reconciliation_report(self, data: Dict[str, Any], output_path: str) -> bool:
        """Generate tank reconciliation report PDF"""
        try:
            doc = SimpleDocTemplate(output_path, pagesize=letter)
            story = []
            
            # Title
            story.append(Paragraph("TANK RECONCILIATION REPORT", self.styles['CustomTitle']))
            story.append(Spacer(1, 0.3*inch))
            
            # Report Information
            info_data = [
                ['Report Date:', datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')],
                ['Reconciliation Period:', f"{data['start_date']} to {data['end_date']}"],
                ['Facility:', data.get('facility_name', 'All Facilities')]
            ]
            
            info_table = Table(info_data, colWidths=[2*inch, 4*inch])
            info_table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ]))
            
            story.append(info_table)
            story.append(Spacer(1, 0.5*inch))
            
            # Tank Reconciliation Summary
            for tank in data.get('tanks', []):
                story.append(Paragraph(f"Tank {tank['tank_number']} - {tank['product']}", self.styles['CustomHeading']))
                
                # Opening/Closing Balance
                balance_data = [
                    ['', 'Volume (BBL)', 'Temperature (°F)'],
                    ['Opening Balance:', f"{tank['opening_volume']:,.2f}", f"{tank['opening_temp']:.1f}"],
                    ['Receipts:', f"{tank['receipts']:,.2f}", ''],
                    ['Deliveries:', f"{tank['deliveries']:,.2f}", ''],
                    ['Calculated Closing:', f"{tank['calculated_closing']:,.2f}", ''],
                    ['Actual Closing:', f"{tank['actual_closing']:,.2f}", f"{tank['closing_temp']:.1f}"],
                    ['Variance:', f"{tank['variance']:,.2f}", f"{tank['variance_percent']:.2f}%"]
                ]
                
                balance_table = Table(balance_data, colWidths=[2*inch, 2*inch, 2*inch])
                balance_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTNAME', (0, 1), (0, -1), 'Helvetica-Bold'),
                    ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ('BACKGROUND', (0, -1), (-1, -1), colors.yellow if abs(tank['variance_percent']) > 0.5 else colors.lightgreen)
                ]))
                
                story.append(balance_table)
                story.append(Spacer(1, 0.3*inch))
                
                # Transaction Details
                if tank.get('transactions'):
                    story.append(Paragraph("Transaction Details", self.styles['Heading3']))
                    
                    trans_data = [['Date/Time', 'Type', 'BOL #', 'Volume (BBL)', 'Running Balance']]
                    
                    for trans in tank['transactions']:
                        trans_data.append([
                            trans['datetime'],
                            trans['type'],
                            trans['bol_number'],
                            f"{trans['volume']:,.2f}",
                            f"{trans['running_balance']:,.2f}"
                        ])
                    
                    trans_table = Table(trans_data)
                    trans_table.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, -1), 9),
                        ('ALIGN', (3, 0), (-1, -1), 'RIGHT'),
                        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey)
                    ]))
                    
                    story.append(trans_table)
                
                story.append(PageBreak())
            
            # Build PDF
            doc.build(story)
            logger.info(f"Reconciliation report generated: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error generating reconciliation report: {e}")
            return False
    
    async def generate_operational_report(self, data: Dict[str, Any], output_path: str) -> bool:
        """Generate operational report with charts"""
        try:
            doc = SimpleDocTemplate(output_path, pagesize=letter)
            story = []
            
            # Title
            story.append(Paragraph("OPERATIONAL REPORT", self.styles['CustomTitle']))
            story.append(Spacer(1, 0.3*inch))
            
            # Key Metrics
            story.append(Paragraph("Key Performance Indicators", self.styles['CustomHeading']))
            
            kpi_data = [
                ['Metric', 'Value', 'Target', 'Status'],
                ['Total Volume Loaded', f"{data['total_volume']:,.0f} BBL", f"{data['target_volume']:,.0f} BBL", 
                 '✓' if data['total_volume'] >= data['target_volume'] else '✗'],
                ['Loading Efficiency', f"{data['loading_efficiency']:.1f}%", "95%", 
                 '✓' if data['loading_efficiency'] >= 95 else '✗'],
                ['Bay Utilization', f"{data['bay_utilization']:.1f}%", "85%", 
                 '✓' if data['bay_utilization'] >= 85 else '✗'],
                ['Safety Incidents', str(data['safety_incidents']), "0", 
                 '✓' if data['safety_incidents'] == 0 else '✗']
            ]
            
            kpi_table = Table(kpi_data, colWidths=[2*inch, 2*inch, 1.5*inch, 1*inch])
            kpi_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(kpi_table)
            story.append(Spacer(1, 0.5*inch))
            
            # Daily Volume Chart
            if data.get('daily_volumes'):
                story.append(Paragraph("Daily Loading Volumes", self.styles['CustomHeading']))
                
                drawing = Drawing(400, 200)
                chart = VerticalBarChart()
                chart.x = 50
                chart.y = 50
                chart.height = 125
                chart.width = 300
                
                chart.data = [data['daily_volumes']['values']]
                chart.categoryAxis.categoryNames = data['daily_volumes']['labels']
                chart.valueAxis.valueMin = 0
                chart.valueAxis.valueMax = max(data['daily_volumes']['values']) * 1.1
                
                drawing.add(chart)
                story.append(drawing)
            
            # Build PDF
            doc.build(story)
            logger.info(f"Operational report generated: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error generating operational report: {e}")
            return False