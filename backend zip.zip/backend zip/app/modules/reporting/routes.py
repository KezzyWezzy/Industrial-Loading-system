﻿from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db

router = APIRouter(prefix="/reporting", tags=["reporting"])

@router.get("/")
async def get_reporting(db: Session = Depends(get_db)):
    return {"message": "reporting system", "data": []}

@router.get("/health")
async def reporting_health():
    return {"status": "healthy", "module": "reporting"}
