# backend/app/modules/reporting/models.py
from sqlalchemy import Column, String, DateTime, Boolean, ForeignKey, Text, JSON, DECIMAL
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from app.core.database import Base
import uuid
from datetime import datetime

class Report(Base):
    __tablename__ = "reports"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    report_type = Column(String(50), nullable=False)
    report_name = Column(String(200), nullable=False)
    parameters = Column(JSON)
    file_path = Column(String(500))
    status = Column(String(50), default="pending")  # pending, generating, completed, failed
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    error_message = Column(Text)
    
    # Relationships
    creator = relationship("User")

class ScheduledReport(Base):
    __tablename__ = "scheduled_reports"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    report_type = Column(String(50), nullable=False)
    schedule_type = Column(String(20), nullable=False)  # daily, weekly, monthly
    schedule_time = Column(String(10))  # HH:MM format
    schedule_day = Column(String(20))  # For weekly/monthly
    parameters = Column(JSON)
    recipients = Column(JSON)  # List of email addresses
    is_active = Column(Boolean, default=True)
    last_run = Column(DateTime)
    next_run = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)