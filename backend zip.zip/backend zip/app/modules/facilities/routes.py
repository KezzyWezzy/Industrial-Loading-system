﻿"""
Facilities routes for the industrial loading system
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.database import get_db

router = APIRouter(prefix="/facilities", tags=["facilities"])


@router.get("/")
async def get_facilities(db: Session = Depends(get_db)):
    """Get all facilities"""
    return {"facilities": [{"id": 1, "name": "Main Loading Facility", "code": "MLF001"}]}


@router.get("/health")
async def facilities_health():
    """Facilities health check"""
    return {"status": "healthy", "module": "facilities"}
