# backend/app/modules/facilities/service.py
from sqlalchemy.orm import Session
from sqlalchemy import and_, func
from typing import List, Optional
import uuid

from app.modules.facilities.models import Facility
from app.modules.facilities.schemas import FacilityCreate, FacilityUpdate
from app.core.exceptions import NotFoundError, ValidationError

class FacilityService:
    def __init__(self, db: Session):
        self.db = db
    
    def create_facility(self, facility_data: FacilityCreate) -> Facility:
        """Create a new facility"""
        # Check if code already exists
        existing = self.db.query(Facility).filter(
            Facility.code == facility_data.code
        ).first()
        
        if existing:
            raise ValidationError(f"Facility with code {facility_data.code} already exists")
        
        facility = Facility(**facility_data.dict())
        self.db.add(facility)
        self.db.commit()
        self.db.refresh(facility)
        return facility
    
    def get_facility(self, facility_id: uuid.UUID) -> Facility:
        """Get facility by ID"""
        facility = self.db.query(Facility).filter(
            Facility.id == facility_id
        ).first()
        
        if not facility:
            raise NotFoundError("Facility not found")
        
        return facility
    
    def get_facilities(self, skip: int = 0, limit: int = 100, active_only: bool = True) -> List[Facility]:
        """Get all facilities"""
        query = self.db.query(Facility)
        
        if active_only:
            query = query.filter(Facility.is_active == True)
        
        return query.offset(skip).limit(limit).all()
    
    def update_facility(self, facility_id: uuid.UUID, facility_data: FacilityUpdate) -> Facility:
        """Update facility information"""
        facility = self.get_facility(facility_id)
        
        for field, value in facility_data.dict(exclude_unset=True).items():
            setattr(facility, field, value)
        
        facility.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(facility)
        return facility