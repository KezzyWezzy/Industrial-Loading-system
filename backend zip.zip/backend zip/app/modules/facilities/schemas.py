# backend/app/modules/facilities/schemas.py
from pydantic import BaseModel, Field, EmailStr
from typing import Optional
from datetime import datetime
from decimal import Decimal
import uuid

class FacilityBase(BaseModel):
    name: str = Field(..., max_length=200)
    code: str = Field(..., max_length=50)
    address: Optional[str] = Field(None, max_length=500)
    latitude: Optional[Decimal] = Field(None, ge=-90, le=90, decimal_places=8)
    longitude: Optional[Decimal] = Field(None, ge=-180, le=180, decimal_places=8)
    contact_phone: Optional[str] = Field(None, max_length=20)
    contact_email: Optional[EmailStr] = None

class FacilityCreate(FacilityBase):
    pass

class FacilityUpdate(BaseModel):
    name: Optional[str] = Field(None, max_length=200)
    address: Optional[str] = Field(None, max_length=500)
    latitude: Optional[Decimal] = Field(None, ge=-90, le=90, decimal_places=8)
    longitude: Optional[Decimal] = Field(None, ge=-180, le=180, decimal_places=8)
    contact_phone: Optional[str] = Field(None, max_length=20)
    contact_email: Optional[EmailStr] = None
    is_active: Optional[bool] = None

class FacilityResponse(FacilityBase):
    id: uuid.UUID
    is_active: bool
    created_at: datetime
    updated_at: datetime
    tank_count: Optional[int] = 0
    loading_bay_count: Optional[int] = 0
    
    class Config:
        from_attributes = True