# backend/app/modules/transactions/schemas.py
from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime
from decimal import Decimal
import uuid

from app.modules.transactions.models import TransactionType, TransactionStatus

class TransactionBase(BaseModel):
    transaction_type: TransactionType
    loading_bay_id: uuid.UUID
    vehicle_type: str = Field(..., max_length=50)
    vehicle_id: str = Field(..., max_length=100)
    driver_name: str = Field(..., max_length=200)
    driver_license: Optional[str] = Field(None, max_length=50)
    carrier_id: Optional[uuid.UUID] = None
    product_id: uuid.UUID
    source_tank: Optional[str] = Field(None, max_length=50)
    destination_tank: Optional[str] = Field(None, max_length=50)
    planned_volume: Decimal = Field(..., gt=0, decimal_places=2)
    customer_id: Optional[uuid.UUID] = None
    ship_to_location: Optional[str] = Field(None, max_length=200)
    purchase_order: Optional[str] = Field(None, max_length=50)

class TransactionCreate(TransactionBase):
    facility_id: uuid.UUID
    
    @validator('source_tank', 'destination_tank')
    def validate_tanks(cls, v, values):
        if 'transaction_type' in values:
            if values['transaction_type'] == TransactionType.LOADING and not values.get('source_tank'):
                raise ValueError('Source tank required for loading transactions')
            elif values['transaction_type'] == TransactionType.DISCHARGE and not values.get('destination_tank'):
                raise ValueError('Destination tank required for discharge transactions')
        return v

class TransactionUpdate(BaseModel):
    status: Optional[TransactionStatus] = None
    actual_volume: Optional[Decimal] = Field(None, decimal_places=2)
    gross_weight: Optional[Decimal] = Field(None, decimal_places=2)
    tare_weight: Optional[Decimal] = Field(None, decimal_places=2)
    net_weight: Optional[Decimal] = Field(None, decimal_places=2)
    temperature: Optional[Decimal] = Field(None, decimal_places=2)
    api_gravity: Optional[Decimal] = Field(None, decimal_places=2)
    observed_gravity: Optional[Decimal] = Field(None, decimal_places=3)
    bsw: Optional[Decimal] = Field(None, decimal_places=2)
    seal_numbers: Optional[List[str]] = None
    end_time: Optional[datetime] = None

class TransactionResponse(TransactionBase):
    id: uuid.UUID
    transaction_number: str
    status: TransactionStatus
    facility_id: uuid.UUID
    actual_volume: Optional[Decimal]
    gross_weight: Optional[Decimal]
    tare_weight: Optional[Decimal]
    net_weight: Optional[Decimal]
    temperature: Optional[Decimal]
    api_gravity: Optional[Decimal]
    observed_gravity: Optional[Decimal]
    bsw: Optional[Decimal]
    bol_number: Optional[str]
    seal_numbers: Optional[List[str]]
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    operator_id: Optional[uuid.UUID]
    
    class Config:
        from_attributes = True
        json_encoders = {
            Decimal: lambda v: float(v)
        }

class TransactionLineItemCreate(BaseModel):
    compartment_number: int = Field(..., ge=1)
    product_id: uuid.UUID
    planned_volume: Decimal = Field(..., gt=0, decimal_places=2)
    temperature: Optional[Decimal] = Field(None, decimal_places=2)

class TransactionLineItemUpdate(BaseModel):
    actual_volume: Optional[Decimal] = Field(None, decimal_places=2)
    temperature: Optional[Decimal] = Field(None, decimal_places=2)
    meter_start: Optional[Decimal] = Field(None, decimal_places=2)
    meter_end: Optional[Decimal] = Field(None, decimal_places=2)
    meter_factor: Optional[Decimal] = Field(None, decimal_places=4)

class TransactionLineItemResponse(BaseModel):
    id: uuid.UUID
    transaction_id: uuid.UUID
    compartment_number: int
    product_id: uuid.UUID
    planned_volume: Decimal
    actual_volume: Optional[Decimal]
    temperature: Optional[Decimal]
    meter_start: Optional[Decimal]
    meter_end: Optional[Decimal]
    meter_factor: Optional[Decimal]
    created_at: datetime
    
    class Config:
        from_attributes = True

class TransactionEventCreate(BaseModel):
    event_type: str = Field(..., max_length=50)
    description: Optional[str] = None
    old_value: Optional[str] = Field(None, max_length=200)
    new_value: Optional[str] = Field(None, max_length=200)

class TransactionEventResponse(BaseModel):
    id: uuid.UUID
    transaction_id: uuid.UUID
    event_type: str
    event_time: datetime
    description: Optional[str]
    old_value: Optional[str]
    new_value: Optional[str]
    user_id: Optional[uuid.UUID]
    created_at: datetime
    
    class Config:
        from_attributes = True

class TransactionSummary(BaseModel):
    total_transactions: int
    loading_count: int
    discharge_count: int
    transfer_count: int
    total_volume: Decimal
    total_weight: Decimal
    pending_count: int
    in_progress_count: int
    completed_count: int
