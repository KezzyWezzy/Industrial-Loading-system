# backend/app/modules/transactions/service.py
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, func
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from decimal import Decimal
import uuid
import json

from app.modules.transactions.models import Transaction, TransactionLineItem, TransactionEvent
from app.modules.transactions.models import TransactionType, TransactionStatus
from app.modules.transactions.schemas import TransactionCreate, TransactionUpdate
from app.modules.loading_bays.models import LoadingBay, LoadingBayStatus
from app.modules.tanks.models import Tank
from app.core.exceptions import NotFoundError, ValidationError
from app.modules.websocket.connection_manager import connection_manager

import logging
logger = logging.getLogger(__name__)

class TransactionService:
    def __init__(self, db: Session):
        self.db = db
    
    def create_transaction(self, transaction_data: TransactionCreate, user_id: uuid.UUID) -> Transaction:
        """Create a new transaction"""
        # Validate loading bay is available
        loading_bay = self.db.query(LoadingBay).filter(
            LoadingBay.id == transaction_data.loading_bay_id
        ).first()
        
        if not loading_bay:
            raise NotFoundError("Loading bay not found")
        
        if loading_bay.status != LoadingBayStatus.AVAILABLE:
            raise ValidationError(f"Loading bay {loading_bay.bay_number} is not available")
        
        # Validate source/destination tanks exist
        if transaction_data.transaction_type == TransactionType.LOADING and transaction_data.source_tank:
            source_tank = self.db.query(Tank).filter(
                Tank.tank_number == transaction_data.source_tank
            ).first()
            if not source_tank:
                raise NotFoundError(f"Source tank {transaction_data.source_tank} not found")
            
            # Check if tank has sufficient inventory
            if source_tank.current_volume and source_tank.current_volume < transaction_data.planned_volume:
                raise ValidationError(f"Insufficient inventory in tank {transaction_data.source_tank}")
        
        # Generate transaction number
        transaction_number = self._generate_transaction_number()
        
        # Create transaction
        transaction = Transaction(
            **transaction_data.dict(),
            transaction_number=transaction_number,
            created_by=user_id,
            operator_id=user_id,
            start_time=datetime.utcnow()
        )
        
        self.db.add(transaction)
        
        # Update loading bay status
        loading_bay.status = LoadingBayStatus.OCCUPIED
        loading_bay.current_transaction_id = transaction.id
        loading_bay.current_vehicle_id = transaction.vehicle_id
        loading_bay.current_operator_id = user_id
        
        # Create initial event
        event = TransactionEvent(
            transaction_id=transaction.id,
            event_type="transaction_created",
            event_time=datetime.utcnow(),
            description=f"Transaction created by {user_id}",
            user_id=user_id
        )
        self.db.add(event)
        
        self.db.commit()
        self.db.refresh(transaction)
        
        # Notify via WebSocket
        asyncio.create_task(self._notify_transaction_update(transaction.id, "created"))
        
        return transaction
    
    def get_transaction(self, transaction_id: uuid.UUID) -> Transaction:
        """Get transaction by ID"""
        transaction = self.db.query(Transaction).filter(
            Transaction.id == transaction_id
        ).first()
        
        if not transaction:
            raise NotFoundError("Transaction not found")
        
        return transaction
    
    def get_transactions(self, facility_id: Optional[uuid.UUID] = None,
                        status: Optional[TransactionStatus] = None,
                        start_date: Optional[datetime] = None,
                        end_date: Optional[datetime] = None,
                        skip: int = 0, limit: int = 100) -> List[Transaction]:
        """Get transactions with filters"""
        query = self.db.query(Transaction)
        
        if facility_id:
            query = query.filter(Transaction.facility_id == facility_id)
        if status:
            query = query.filter(Transaction.status == status)
        if start_date:
            query = query.filter(Transaction.created_at >= start_date)
        if end_date:
            query = query.filter(Transaction.created_at <= end_date)
        
        return query.order_by(desc(Transaction.created_at)).offset(skip).limit(limit).all()
    
    def update_transaction(self, transaction_id: uuid.UUID, 
                          update_data: TransactionUpdate,
                          user_id: uuid.UUID) -> Transaction:
        """Update transaction"""
        transaction = self.get_transaction(transaction_id)
        
        # Track changes for events
        changes = []
        
        # Update fields
        for field, value in update_data.dict(exclude_unset=True).items():
            if hasattr(transaction, field):
                old_value = getattr(transaction, field)
                if old_value != value:
                    changes.append({
                        "field": field,
                        "old_value": str(old_value),
                        "new_value": str(value)
                    })
                    setattr(transaction, field, value)
        
        # Handle seal numbers (stored as JSON)
        if update_data.seal_numbers is not None:
            transaction.seal_numbers = json.dumps(update_data.seal_numbers)
        
        transaction.updated_at = datetime.utcnow()
        
        # Create events for changes
        for change in changes:
            event = TransactionEvent(
                transaction_id=transaction_id,
                event_type=f"field_updated_{change['field']}",
                event_time=datetime.utcnow(),
                description=f"Updated {change['field']}",
                old_value=change['old_value'],
                new_value=change['new_value'],
                user_id=user_id
            )
            self.db.add(event)
        
        self.db.commit()
        self.db.refresh(transaction)
        
        # Notify via WebSocket
        asyncio.create_task(self._notify_transaction_update(transaction_id, "updated"))
        
        return transaction
    
    def start_loading(self, transaction_id: uuid.UUID, user_id: uuid.UUID) -> Transaction:
        """Start loading operation"""
        transaction = self.get_transaction(transaction_id)
        
        if transaction.status != TransactionStatus.PENDING:
            raise ValidationError("Transaction must be pending to start loading")
        
        transaction.status = TransactionStatus.IN_PROGRESS
        transaction.start_time = datetime.utcnow()
        
        # Update loading bay status
        loading_bay = transaction.loading_bay
        loading_bay.status = LoadingBayStatus.LOADING
        
        # Create event
        event = TransactionEvent(
            transaction_id=transaction_id,
            event_type="loading_started",
            event_time=datetime.utcnow(),
            description="Loading operation started",
            user_id=user_id
        )
        self.db.add(event)
        
        self.db.commit()
        self.db.refresh(transaction)
        
        # Notify via WebSocket
        asyncio.create_task(self._notify_transaction_update(transaction_id, "loading_started"))
        
        return transaction
    
    def complete_transaction(self, transaction_id: uuid.UUID, user_id: uuid.UUID) -> Transaction:
        """Complete transaction"""
        transaction = self.get_transaction(transaction_id)
        
        if transaction.status != TransactionStatus.IN_PROGRESS:
            raise ValidationError("Transaction must be in progress to complete")
        
        # Validate required fields
        if not transaction.actual_volume:
            raise ValidationError("Actual volume must be recorded before completing")
        
        # Generate BOL number if not exists
        if not transaction.bol_number:
            transaction.bol_number = self._generate_bol_number()
        
        transaction.status = TransactionStatus.COMPLETED
        transaction.end_time = datetime.utcnow()
        
        # Update loading bay status
        loading_bay = transaction.loading_bay
        loading_bay.status = LoadingBayStatus.AVAILABLE
        loading_bay.current_transaction_id = None
        loading_bay.current_vehicle_id = None
        loading_bay.current_operator_id = None
        
        # Update tank inventory
        if transaction.transaction_type == TransactionType.LOADING and transaction.source_tank:
            tank = self.db.query(Tank).filter(
                Tank.tank_number == transaction.source_tank
            ).first()
            if tank and tank.current_volume:
                tank.current_volume -= transaction.actual_volume
        
        # Create event
        event = TransactionEvent(
            transaction_id=transaction_id,
            event_type="transaction_completed",
            event_time=datetime.utcnow(),
            description="Transaction completed successfully",
            user_id=user_id
        )
        self.db.add(event)
        
        self.db.commit()
        self.db.refresh(transaction)
        
        # Notify via WebSocket
        asyncio.create_task(self._notify_transaction_update(transaction_id, "completed"))
        
        return transaction
    
    def cancel_transaction(self, transaction_id: uuid.UUID, reason: str, user_id: uuid.UUID) -> Transaction:
        """Cancel transaction"""
        transaction = self.get_transaction(transaction_id)
        
        if transaction.status == TransactionStatus.COMPLETED:
            raise ValidationError("Cannot cancel completed transaction")
        
        transaction.status = TransactionStatus.CANCELLED
        
        # Release loading bay if occupied
        if transaction.status in [TransactionStatus.PENDING, TransactionStatus.IN_PROGRESS]:
            loading_bay = transaction.loading_bay
            loading_bay.status = LoadingBayStatus.AVAILABLE
            loading_bay.current_transaction_id = None
            loading_bay.current_vehicle_id = None
            loading_bay.current_operator_id = None
        
        # Create event
        event = TransactionEvent(
            transaction_id=transaction_id,
            event_type="transaction_cancelled",
            event_time=datetime.utcnow(),
            description=f"Transaction cancelled: {reason}",
            user_id=user_id
        )
        self.db.add(event)
        
        self.db.commit()
        self.db.refresh(transaction)
        
        # Notify via WebSocket
        asyncio.create_task(self._notify_transaction_update(transaction_id, "cancelled"))
        
        return transaction
    
    def get_transaction_events(self, transaction_id: uuid.UUID) -> List[TransactionEvent]:
        """Get all events for a transaction"""
        return self.db.query(TransactionEvent).filter(
            TransactionEvent.transaction_id == transaction_id
        ).order_by(TransactionEvent.event_time).all()
    
    def get_transaction_summary(self, facility_id: Optional[uuid.UUID] = None,
                               date: Optional[datetime] = None) -> Dict[str, Any]:
        """Get transaction summary statistics"""
        query = self.db.query(Transaction)
        
        if facility_id:
            query = query.filter(Transaction.facility_id == facility_id)
        
        if date:
            start = date.replace(hour=0, minute=0, second=0, microsecond=0)
            end = start + timedelta(days=1)
            query = query.filter(
                and_(
                    Transaction.created_at >= start,
                    Transaction.created_at < end
                )
            )
        
        transactions = query.all()
        
        summary = {
            "total_transactions": len(transactions),
            "loading_count": sum(1 for t in transactions if t.transaction_type == TransactionType.LOADING),
            "discharge_count": sum(1 for t in transactions if t.transaction_type == TransactionType.DISCHARGE),
            "transfer_count": sum(1 for t in transactions if t.transaction_type == TransactionType.TRANSFER),
            "total_volume": sum(t.actual_volume or 0 for t in transactions),
            "total_weight": sum(t.net_weight or 0 for t in transactions),
            "pending_count": sum(1 for t in transactions if t.status == TransactionStatus.PENDING),
            "in_progress_count": sum(1 for t in transactions if t.status == TransactionStatus.IN_PROGRESS),
            "completed_count": sum(1 for t in transactions if t.status == TransactionStatus.COMPLETED)
        }
        
        return summary
    
    def _generate_transaction_number(self) -> str:
        """Generate unique transaction number"""
        date_part = datetime.utcnow().strftime('%Y%m%d')
        
        # Get count of transactions today
        today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        count = self.db.query(Transaction).filter(
            Transaction.created_at >= today_start
        ).count()
        
        return f"TXN-{date_part}-{count + 1:04d}"
    
    def _generate_bol_number(self) -> str:
        """Generate unique BOL number"""
        date_part = datetime.utcnow().strftime('%Y%m%d')
        
        # Get count of BOLs today
        today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        count = self.db.query(Transaction).filter(
            and_(
                Transaction.created_at >= today_start,
                Transaction.bol_number.isnot(None)
            )
        ).count()
        
        return f"BOL-{date_part}-{count + 1:04d}"
    
    async def _notify_transaction_update(self, transaction_id: uuid.UUID, event_type: str):
        """Send WebSocket notification for transaction update"""
        transaction = self.db.query(Transaction).filter(
            Transaction.id == transaction_id
        ).first()
        
        if transaction:
            await connection_manager.publish_to_topic(
                f"transaction_{transaction_id}",
                {
                    "type": f"transaction_{event_type}",
                    "transaction_id": str(transaction_id),
                    "status": transaction.status.value,
                    "loading_bay_id": str(transaction.loading_bay_id),
                    "timestamp": datetime.utcnow().isoformat()
                }
            )


