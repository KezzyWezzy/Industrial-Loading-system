# backend/app/modules/transactions/models.py
from sqlalchemy import Column, String, DECIMAL, Integer, DateTime, Boolean, ForeignKey, Text, Enum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from app.core.database import Base
import uuid
from datetime import datetime
import enum

class TransactionType(enum.Enum):
    LOADING = "loading"
    DISCHARGE = "discharge"
    TRANSFER = "transfer"

class TransactionStatus(enum.Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    ON_HOLD = "on_hold"

class Transaction(Base):
    __tablename__ = "transactions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    transaction_number = Column(String(50), unique=True, nullable=False)
    transaction_type = Column(Enum(TransactionType), nullable=False)
    status = Column(Enum(TransactionStatus), default=TransactionStatus.PENDING)
    
    # Facility and location
    facility_id = Column(UUID(as_uuid=True), ForeignKey("facilities.id"))
    loading_bay_id = Column(UUID(as_uuid=True), ForeignKey("loading_bays.id"))
    
    # Vehicle information
    vehicle_type = Column(String(50))  # truck, rail_car, barge
    vehicle_id = Column(String(100))
    driver_name = Column(String(200))
    driver_license = Column(String(50))
    carrier_id = Column(UUID(as_uuid=True), ForeignKey("carriers.id"))
    
    # Product information
    product_id = Column(UUID(as_uuid=True), ForeignKey("products.id"))
    source_tank = Column(String(50))
    destination_tank = Column(String(50))
    
    # Quantities
    planned_volume = Column(DECIMAL(12, 2))  # BBL
    actual_volume = Column(DECIMAL(12, 2))   # BBL
    gross_weight = Column(DECIMAL(12, 2))    # LBS
    tare_weight = Column(DECIMAL(12, 2))     # LBS
    net_weight = Column(DECIMAL(12, 2))      # LBS
    
    # Quality data
    temperature = Column(DECIMAL(6, 2))      # °F
    api_gravity = Column(DECIMAL(5, 2))
    observed_gravity = Column(DECIMAL(5, 3))
    bsw = Column(DECIMAL(5, 2))             # Basic sediment and water %
    
    # Documentation
    bol_number = Column(String(50), unique=True)
    purchase_order = Column(String(50))
    seal_numbers = Column(Text)  # JSON array of seal numbers
    
    # Customer information
    customer_id = Column(UUID(as_uuid=True), ForeignKey("customers.id"))
    ship_to_location = Column(String(200))
    
    # Timestamps
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # User tracking
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    operator_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    approved_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    
    # Relationships
    facility = relationship("Facility")
    loading_bay = relationship("LoadingBay")
    carrier = relationship("Carrier")
    product = relationship("Product")
    customer = relationship("Customer")
    creator = relationship("User", foreign_keys=[created_by])
    operator = relationship("User", foreign_keys=[operator_id])
    approver = relationship("User", foreign_keys=[approved_by])
    
    # Related models
    line_items = relationship("TransactionLineItem", back_populates="transaction")
    events = relationship("TransactionEvent", back_populates="transaction")
    quality_tests = relationship("QualityTest", back_populates="transaction")


class TransactionLineItem(Base):
    __tablename__ = "transaction_line_items"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    transaction_id = Column(UUID(as_uuid=True), ForeignKey("transactions.id"))
    compartment_number = Column(Integer)
    
    # Product and quantities
    product_id = Column(UUID(as_uuid=True), ForeignKey("products.id"))
    planned_volume = Column(DECIMAL(12, 2))
    actual_volume = Column(DECIMAL(12, 2))
    temperature = Column(DECIMAL(6, 2))
    
    # Meter readings
    meter_start = Column(DECIMAL(12, 2))
    meter_end = Column(DECIMAL(12, 2))
    meter_factor = Column(DECIMAL(6, 4), default=1.0000)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    transaction = relationship("Transaction", back_populates="line_items")
    product = relationship("Product")


class TransactionEvent(Base):
    __tablename__ = "transaction_events"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    transaction_id = Column(UUID(as_uuid=True), ForeignKey("transactions.id"))
    event_type = Column(String(50), nullable=False)
    event_time = Column(DateTime, nullable=False)
    description = Column(Text)
    
    # Event data
    old_value = Column(String(200))
    new_value = Column(String(200))
    
    # User who triggered the event
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    transaction = relationship("Transaction", back_populates="events")
    user = relationship("User")




