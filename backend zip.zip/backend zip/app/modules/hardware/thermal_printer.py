# backend/app/modules/hardware/thermal_printer.py
import socket
import asyncio
import logging
from typing import Optional, Dict, Any, List
from datetime import datetime
from escpos.printer import Network

from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

class ThermalPrinter:
    def __init__(self, printer_ip: str = None):
        self.printer_ip = printer_ip or settings.THERMAL_PRINTER_IP
        self.printer = None
    
    async def connect(self) -> bool:
        """Connect to thermal printer"""
        try:
            if self.printer_ip:
                self.printer = Network(self.printer_ip)
                logger.info(f"Connected to thermal printer at {self.printer_ip}")
                return True
            else:
                logger.warning("No printer IP configured")
                return False
        except Exception as e:
            logger.error(f"Failed to connect to thermal printer: {e}")
            return False
    
    async def print_bol(self, bol_data: Dict[str, Any]) -> bool:
        """Print Bill of Lading"""
        try:
            if not self.printer:
                logger.error("Printer not connected")
                return False
            
            # Build BOL document
            self.printer.set(align='center', font='a', bold=True, double_height=True)
            self.printer.text("BILL OF LADING\n")
            self.printer.text("================\n\n")
            
            self.printer.set(align='left', font='a', bold=False, double_height=False)
            
            # BOL Number and Date
            self.printer.text(f"BOL #: {bol_data.get('bol_number', 'N/A')}\n")
            self.printer.text(f"Date: {bol_data.get('date', datetime.utcnow().strftime('%Y-%m-%d %H:%M'))}\n\n")
            
            # Company Information
            self.printer.text("FROM:\n")
            self.printer.text(f"{bol_data.get('company_name', 'Loading Terminal')}\n")
            self.printer.text(f"{bol_data.get('company_address', '')}\n\n")
            
            # Customer Information
            self.printer.text("TO:\n")
            self.printer.text(f"{bol_data.get('customer_name', '')}\n")
            self.printer.text(f"{bol_data.get('customer_address', '')}\n\n")
            
            # Vehicle Information
            self.printer.text(f"Vehicle: {bol_data.get('vehicle_id', '')}\n")
            self.printer.text(f"Driver: {bol_data.get('driver_name', '')}\n")
            self.printer.text(f"Carrier: {bol_data.get('carrier_name', '')}\n\n")
            
            # Product Information
            self.printer.set(bold=True)
            self.printer.text("PRODUCT INFORMATION:\n")
            self.printer.set(bold=False)
            self.printer.text(f"Product: {bol_data.get('product_name', '')}\n")
            self.printer.text(f"Tank: {bol_data.get('source_tank', '')}\n")
            self.printer.text(f"Bay: {bol_data.get('loading_bay', '')}\n\n")
            
            # Volume Information
            self.printer.set(bold=True)
            self.printer.text("QUANTITIES:\n")
            self.printer.set(bold=False)
            self.printer.text(f"Gross Volume: {bol_data.get('gross_volume', 0):.2f} BBL\n")
            self.printer.text(f"Net Volume: {bol_data.get('net_volume', 0):.2f} BBL\n")
            self.printer.text(f"Temperature: {bol_data.get('temperature', 0):.1f} °F\n\n")
            
            # Weight Information (if available)
            if 'gross_weight' in bol_data:
                self.printer.text(f"Gross Weight: {bol_data.get('gross_weight', 0):.0f} lbs\n")
                self.printer.text(f"Tare Weight: {bol_data.get('tare_weight', 0):.0f} lbs\n")
                self.printer.text(f"Net Weight: {bol_data.get('net_weight', 0):.0f} lbs\n\n")
            
            # Seals
            if 'seal_numbers' in bol_data:
                self.printer.text(f"Seal Numbers: {', '.join(bol_data['seal_numbers'])}\n\n")
            
            # Signatures
            self.printer.text("\n\nSHIPPER:\n")
            self.printer.text("_________________________\n")
            self.printer.text(f"{bol_data.get('operator_name', '')}\n\n")
            
            self.printer.text("DRIVER:\n")
            self.printer.text("_________________________\n")
            self.printer.text(f"{bol_data.get('driver_name', '')}\n\n")
            
            # Barcode (if supported)
            if 'bol_number' in bol_data:
                self.printer.barcode(
                    bol_data['bol_number'],
                    'CODE128',
                    height=64,
                    width=2,
                    pos='BELOW'
                )
            
            # Cut paper
            self.printer.cut()
            
            logger.info(f"BOL printed successfully: {bol_data.get('bol_number')}")
            return True
            
        except Exception as e:
            logger.error(f"Error printing BOL: {e}")
            return False
    
    async def print_ticket(self, ticket_data: Dict[str, Any]) -> bool:
        """Print loading ticket"""
        try:
            if not self.printer:
                logger.error("Printer not connected")
                return False
            
            # Build ticket
            self.printer.set(align='center', font='a', bold=True)
            self.printer.text("LOADING TICKET\n")
            self.printer.text("==============\n\n")
            
            self.printer.set(align='left', font='a', bold=False)
            
            # Ticket details
            self.printer.text(f"Ticket #: {ticket_data.get('ticket_number', 'N/A')}\n")
            self.printer.text(f"Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}\n")
            self.printer.text(f"Bay: {ticket_data.get('loading_bay', '')}\n")
            self.printer.text(f"Product: {ticket_data.get('product', '')}\n")
            self.printer.text(f"Volume: {ticket_data.get('volume', 0):.2f} BBL\n")
            self.printer.text(f"Vehicle: {ticket_data.get('vehicle_id', '')}\n")
            
            # Cut paper
            self.printer.cut()
            
            return True
            
        except Exception as e:
            logger.error(f"Error printing ticket: {e}")
            return False
    
    async def print_test_page(self) -> bool:
        """Print test page"""
        try:
            if not self.printer:
                logger.error("Printer not connected")
                return False
            
            self.printer.set(align='center', font='a', bold=True)
            self.printer.text("PRINTER TEST PAGE\n")
            self.printer.text("=================\n\n")
            
            self.printer.set(align='left', font='a', bold=False)
            self.printer.text(f"Date: {datetime.utcnow()}\n")
            self.printer.text("Printer Status: OK\n")
            self.printer.text("Connection: Active\n\n")
            
            self.printer.text("Font Sizes:\n")
            self.printer.set(font='a')
            self.printer.text("Font A (Normal)\n")
            self.printer.set(font='b')
            self.printer.text("Font B (Small)\n\n")
            
            self.printer.set(font='a', bold=True)
            self.printer.text("Bold Text\n")
            self.printer.set(bold=False, underline=True)
            self.printer.text("Underlined Text\n")
            self.printer.set(underline=False)
            
            # Test barcode
            self.printer.barcode('123456789012', 'EAN13', height=64, width=2)
            
            self.printer.cut()
            
            logger.info("Test page printed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error printing test page: {e}")
            return False