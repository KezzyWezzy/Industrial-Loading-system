# backend/app/modules/hardware/weight_scale.py
import serial
import asyncio
import re
import logging
from typing import Optional, Dict, Any, Tuple
from datetime import datetime
from decimal import Decimal

from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

class WeightScale:
    def __init__(self, port: str, baudrate: int = 9600):
        self.port = port
        self.baudrate = baudrate
        self.serial_connection = None
        self.is_reading = False
        self.weight_callbacks = []
        self.current_weight = Decimal('0')
        self.is_stable = False
        self.units = "lb"
    
    async def connect(self) -> bool:
        """Connect to weight scale"""
        try:
            self.serial_connection = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                bytesize=8,
                parity='N',
                stopbits=1,
                timeout=1
            )
            logger.info(f"Connected to weight scale on {self.port}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to weight scale: {e}")
            return False
    
    async def disconnect(self):
        """Disconnect from weight scale"""
        self.is_reading = False
        if self.serial_connection:
            self.serial_connection.close()
            logger.info("Disconnected from weight scale")
    
    async def start_continuous_reading(self):
        """Start continuous weight reading"""
        self.is_reading = True
        
        while self.is_reading:
            try:
                weight_data = await self.read_weight()
                if weight_data:
                    await self._notify_weight_callbacks(weight_data)
                
                await asyncio.sleep(0.5)
                
            except Exception as e:
                logger.error(f"Error during weight reading: {e}")
                await asyncio.sleep(1)
    
    async def stop_continuous_reading(self):
        """Stop continuous weight reading"""
        self.is_reading = False
    
    async def read_weight(self) -> Optional[Dict[str, Any]]:
        """Read current weight from scale"""
        try:
            if not self.serial_connection:
                return None
            
            # Send read command (varies by scale model)
            self.serial_connection.write(b'W\r\n')
            
            # Read response
            response = self.serial_connection.readline().decode('utf-8').strip()
            
            if response:
                return await self._parse_weight_data(response)
            
            return None
            
        except Exception as e:
            logger.error(f"Error reading weight: {e}")
            return None
    
    async def zero_scale(self) -> bool:
        """Zero the scale"""
        try:
            if not self.serial_connection:
                return False
            
            # Send zero command (varies by scale model)
            self.serial_connection.write(b'Z\r\n')
            
            # Wait for confirmation
            response = self.serial_connection.readline().decode('utf-8').strip()
            
            logger.info("Scale zeroed")
            return True
            
        except Exception as e:
            logger.error(f"Error zeroing scale: {e}")
            return False
    
    async def tare_scale(self) -> bool:
        """Tare the scale"""
        try:
            if not self.serial_connection:
                return False
            
            # Send tare command (varies by scale model)
            self.serial_connection.write(b'T\r\n')
            
            # Wait for confirmation
            response = self.serial_connection.readline().decode('utf-8').strip()
            
            logger.info("Scale tared")
            return True
            
        except Exception as e:
            logger.error(f"Error taring scale: {e}")
            return False
    
    async def _parse_weight_data(self, raw_data: str) -> Dict[str, Any]:
        """Parse weight data from scale response"""
        # Common weight scale formats:
        # "ST,GS,+00000.0,lb" - Standard format
        # "+00000.0 lb" - Simple format
        # "S +00000.0 lb" - With stability indicator
        
        weight_data = {
            "raw_data": raw_data,
            "timestamp": datetime.utcnow(),
            "weight": Decimal('0'),
            "units": "lb",
            "stable": False,
            "status": "unknown"
        }
        
        # Try to parse different formats
        # Format 1: "ST,GS,+00000.0,lb"
        pattern1 = r'([A-Z]{2}),([A-Z]{2}),([+-]?\d+\.?\d*),(\w+)'
        match1 = re.match(pattern1, raw_data)
        if match1:
            status, stability, weight, units = match1.groups()
            weight_data["status"] = status
            weight_data["stable"] = stability == "ST"
            weight_data["weight"] = Decimal(weight)
            weight_data["units"] = units
            return weight_data
        
        # Format 2: "S +00000.0 lb"
        pattern2 = r'([SU])\s*([+-]?\d+\.?\d*)\s*(\w+)'
        match2 = re.match(pattern2, raw_data)
        if match2:
            stability, weight, units = match2.groups()
            weight_data["stable"] = stability == "S"
            weight_data["weight"] = Decimal(weight)
            weight_data["units"] = units
            return weight_data
        
        # Format 3: Simple "+00000.0 lb"
        pattern3 = r'([+-]?\d+\.?\d*)\s*(\w+)'
        match3 = re.match(pattern3, raw_data)
        if match3:
            weight, units = match3.groups()
            weight_data["weight"] = Decimal(weight)
            weight_data["units"] = units
            weight_data["stable"] = True  # Assume stable if no indicator
            return weight_data
        
        logger.warning(f"Unable to parse weight data: {raw_data}")
        return weight_data
    
    async def get_stable_weight(self, timeout: int = 10) -> Optional[Decimal]:
        """Wait for and return stable weight reading"""
        start_time = datetime.utcnow()
        
        while (datetime.utcnow() - start_time).seconds < timeout:
            weight_data = await self.read_weight()
            
            if weight_data and weight_data["stable"]:
                return weight_data["weight"]
            
            await asyncio.sleep(0.5)
        
        logger.warning("Timeout waiting for stable weight")
        return None
    
    def register_weight_callback(self, callback):
        """Register callback for weight updates"""
        self.weight_callbacks.append(callback)
    
    async def _notify_weight_callbacks(self, weight_data: Dict[str, Any]):
        """Notify all registered callbacks"""
        for callback in self.weight_callbacks:
            try:
                await callback(weight_data)
            except Exception as e:
                logger.error(f"Error in weight callback: {e}")