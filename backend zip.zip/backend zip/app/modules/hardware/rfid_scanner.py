# backend/app/modules/hardware/rfid_scanner.py
import serial
import asyncio
import logging
from typing import Optional, Dict, Any
from datetime import datetime

from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

class RFIDScanner:
    def __init__(self, port: str = None):
        self.port = port or settings.RFID_SCANNER_PORT
        self.serial_connection = None
        self.is_scanning = False
        self.scan_callbacks = []
    
    async def connect(self) -> bool:
        """Connect to RFID scanner"""
        try:
            self.serial_connection = serial.Serial(
                port=self.port,
                baudrate=9600,
                bytesize=8,
                parity='N',
                stopbits=1,
                timeout=1
            )
            logger.info(f"Connected to RFID scanner on {self.port}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to RFID scanner: {e}")
            return False
    
    async def disconnect(self):
        """Disconnect from RFID scanner"""
        if self.serial_connection:
            self.serial_connection.close()
            logger.info("Disconnected from RFID scanner")
    
    async def start_scanning(self):
        """Start continuous RFID scanning"""
        self.is_scanning = True
        
        while self.is_scanning:
            try:
                if self.serial_connection and self.serial_connection.in_waiting:
                    tag_data = self.serial_connection.readline().decode('utf-8').strip()
                    
                    if tag_data:
                        tag_info = await self._parse_tag_data(tag_data)
                        await self._notify_scan_callbacks(tag_info)
                
                await asyncio.sleep(0.1)
                
            except Exception as e:
                logger.error(f"Error during RFID scanning: {e}")
                await asyncio.sleep(1)
    
    async def stop_scanning(self):
        """Stop RFID scanning"""
        self.is_scanning = False
    
    async def read_tag(self) -> Optional[Dict[str, Any]]:
        """Read single RFID tag"""
        try:
            if self.serial_connection:
                # Send read command if needed
                self.serial_connection.write(b'READ\r\n')
                
                # Wait for response
                response = self.serial_connection.readline().decode('utf-8').strip()
                
                if response:
                    return await self._parse_tag_data(response)
            
            return None
            
        except Exception as e:
            logger.error(f"Error reading RFID tag: {e}")
            return None
    
    async def _parse_tag_data(self, raw_data: str) -> Dict[str, Any]:
        """Parse RFID tag data"""
        # Basic parsing - adapt based on your RFID format
        return {
            "tag_id": raw_data,
            "timestamp": datetime.utcnow(),
            "reader_id": self.port
        }
    
    def register_scan_callback(self, callback):
        """Register callback for tag scans"""
        self.scan_callbacks.append(callback)
    
    async def _notify_scan_callbacks(self, tag_info: Dict[str, Any]):
        """Notify all registered callbacks"""
        for callback in self.scan_callbacks:
            try:
                await callback(tag_info)
            except Exception as e:
                logger.error(f"Error in scan callback: {e}")