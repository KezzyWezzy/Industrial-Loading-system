# backend/app/modules/hardware/trik_card.py
import serial
import asyncio
import re
import logging
from typing import Optional, Dict, Any
from datetime import datetime

from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

class TrikCardScanner:
    def __init__(self, port: str = "/dev/ttyUSB1", baudrate: int = 9600):
        self.port = port
        self.baudrate = baudrate
        self.serial_connection = None
        self.is_scanning = False
        self.scan_callbacks = []
    
    async def connect(self) -> bool:
        """Connect to Trik Card scanner"""
        try:
            self.serial_connection = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                bytesize=8,
                parity='N',
                stopbits=1,
                timeout=1
            )
            logger.info(f"Connected to Trik Card scanner on {self.port}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to Trik Card scanner: {e}")
            return False
    
    async def disconnect(self):
        """Disconnect from Trik Card scanner"""
        self.is_scanning = False
        if self.serial_connection:
            self.serial_connection.close()
            logger.info("Disconnected from Trik Card scanner")
    
    async def start_scanning(self):
        """Start continuous card scanning"""
        self.is_scanning = True
        
        while self.is_scanning:
            try:
                if self.serial_connection and self.serial_connection.in_waiting:
                    card_data = self.serial_connection.readline().decode('utf-8').strip()
                    
                    if card_data:
                        card_info = await self._parse_card_data(card_data)
                        await self._notify_scan_callbacks(card_info)
                
                await asyncio.sleep(0.1)
                
            except Exception as e:
                logger.error(f"Error during Trik Card scanning: {e}")
                await asyncio.sleep(1)
    
    async def stop_scanning(self):
        """Stop card scanning"""
        self.is_scanning = False
    
    async def read_card(self) -> Optional[Dict[str, Any]]:
        """Read single card"""
        try:
            if not self.serial_connection:
                return None
            
            # Clear buffer
            self.serial_connection.reset_input_buffer()
            
            # Wait for card swipe
            start_time = datetime.utcnow()
            timeout = 30  # 30 second timeout
            
            while (datetime.utcnow() - start_time).seconds < timeout:
                if self.serial_connection.in_waiting:
                    card_data = self.serial_connection.readline().decode('utf-8').strip()
                    if card_data:
                        return await self._parse_card_data(card_data)
                
                await asyncio.sleep(0.1)
            
            return None
            
        except Exception as e:
            logger.error(f"Error reading Trik Card: {e}")
            return None
    
    async def _parse_card_data(self, raw_data: str) -> Dict[str, Any]:
        """Parse Trik Card data"""
        card_info = {
            "raw_data": raw_data,
            "timestamp": datetime.utcnow(),
            "card_number": None,
            "driver_id": None,
            "company_code": None,
            "expiration": None,
            "access_level": None,
            "valid": False
        }
        
        # Trik Card format typically includes:
        # - Card number
        # - Driver ID
        # - Company code
        # - Expiration date
        # - Access privileges
        
        # Example format: "%B1234567890^SMITH/JOHN^2512101?"
        # This is a simplified parser - adapt to your actual card format
        
        # Try magnetic stripe format
        mag_pattern = r'%B(\d+)\^([^/]+)/([^\^]+)\^(\d{4})(\d+)\?'
        mag_match = re.match(mag_pattern, raw_data)
        
        if mag_match:
            card_number, last_name, first_name, exp_date, extra = mag_match.groups()
            
            card_info["card_number"] = card_number
            card_info["driver_id"] = f"{first_name} {last_name}"
            
            # Parse expiration date (YYMM format)
            try:
                exp_year = int("20" + exp_date[:2])
                exp_month = int(exp_date[2:4])
                card_info["expiration"] = datetime(exp_year, exp_month, 1)
                card_info["valid"] = datetime.utcnow() < card_info["expiration"]
            except:
                logger.warning(f"Failed to parse expiration date: {exp_date}")
            
            # Extract company code from extra data if present
            if len(extra) >= 3:
                card_info["company_code"] = extra[:3]
            
            return card_info
        
        # Try barcode format (simpler numeric format)
        barcode_pattern = r'(\d{10,20})'
        barcode_match = re.match(barcode_pattern, raw_data)
        
        if barcode_match:
            card_info["card_number"] = barcode_match.group(1)
            card_info["valid"] = True  # Basic validation
            return card_info
        
        logger.warning(f"Unable to parse Trik Card data: {raw_data}")
        return card_info
    
    async def validate_card(self, card_info: Dict[str, Any]) -> Dict[str, Any]:
        """Validate card against database"""
        validation_result = {
            "valid": False,
            "driver_authorized": False,
            "company_authorized": False,
            "message": "Unknown card"
        }
        
        if not card_info.get("card_number"):
            validation_result["message"] = "Invalid card format"
            return validation_result
        
        # Check expiration
        if card_info.get("expiration"):
            if datetime.utcnow() > card_info["expiration"]:
                validation_result["message"] = "Card expired"
                return validation_result
        
        # TODO: Implement actual database validation
        # This would check:
        # - Card number exists in database
        # - Driver is authorized
        # - Company is authorized
        # - Any loading restrictions
        
        # For now, simple validation
        if card_info.get("card_number"):
            validation_result["valid"] = True
            validation_result["driver_authorized"] = True
            validation_result["company_authorized"] = True
            validation_result["message"] = "Card validated successfully"
        
        return validation_result
    
    def register_scan_callback(self, callback):
        """Register callback for card scans"""
        self.scan_callbacks.append(callback)
    
    async def _notify_scan_callbacks(self, card_info: Dict[str, Any]):
        """Notify all registered callbacks"""
        for callback in self.scan_callbacks:
            try:
                await callback(card_info)
            except Exception as e:
                logger.error(f"Error in scan callback: {e}")