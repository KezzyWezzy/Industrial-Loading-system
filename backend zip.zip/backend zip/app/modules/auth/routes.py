﻿"""
Authentication routes for the industrial loading system
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional

from app.core.database import get_db
from app.modules.auth.service import AuthService
from app.modules.auth.models import User, Role, Permission, UserSession

router = APIRouter(prefix="/auth", tags=["authentication"])


@router.get("/")
async def auth_status():
    """Authentication system status"""
    return {"message": "Authentication system", "status": "operational"}


@router.get("/health")
async def auth_health():
    """Authentication health check"""
    return {"status": "healthy", "module": "auth"}


@router.post("/login")
async def login(username: str, password: str, db: Session = Depends(get_db)):
    """User login endpoint"""
    service = AuthService(db)
    result = service.authenticate_user(username, password)
    return {"message": "Login successful", "user": result}


@router.get("/users")
async def get_users(db: Session = Depends(get_db)):
    """Get all users"""
    return {"users": [{"id": 1, "username": "admin", "email": "admin@example.com"}]}
