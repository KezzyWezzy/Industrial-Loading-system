# backend/app/modules/plc_communication/modbus_tcp.py
from pymodbus.client import AsyncModbusTcpClient
from pymodbus.constants import Endian
from pymodbus.payload import BinaryPayloadDecoder
from typing import Dict, List, Optional, Any
import asyncio
import logging
from datetime import datetime

from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

class ModbusTCPClient:
    def __init__(self):
        self.clients: Dict[str, AsyncModbusTcpClient] = {}
        self.is_running = False
    
    async def connect(self, device_config: dict) -> bool:
        """Connect to Modbus TCP device"""
        ip_address = device_config["ip_address"]
        port = device_config.get("port", settings.MODBUS_TCP_PORT)
        unit_id = device_config.get("unit_id", 1)
        
        try:
            client = AsyncModbusTcpClient(
                host=ip_address,
                port=port,
                timeout=settings.PLC_TIMEOUT
            )
            
            await client.connect()
            
            if client.connected:
                self.clients[ip_address] = client
                logger.info(f"Connected to Modbus TCP device at {ip_address}:{port}")
                return True
            else:
                logger.error(f"Failed to connect to Modbus TCP device at {ip_address}:{port}")
                return False
                
        except Exception as e:
            logger.error(f"Error connecting to Modbus TCP device {ip_address}: {e}")
            return False
    
    async def disconnect(self, ip_address: str):
        """Disconnect from Modbus TCP device"""
        if ip_address in self.clients:
            try:
                await self.clients[ip_address].close()
                del self.clients[ip_address]
                logger.info(f"Disconnected from Modbus TCP device at {ip_address}")
            except Exception as e:
                logger.error(f"Error disconnecting from Modbus TCP device {ip_address}: {e}")
    
    async def read_holding_registers(self, ip_address: str, start_address: int, 
                                   count: int, unit_id: int = 1) -> Optional[List[int]]:
        """Read holding registers from device"""
        if ip_address not in self.clients:
            logger.error(f"No connection to Modbus device {ip_address}")
            return None
        
        client = self.clients[ip_address]
        try:
            result = await client.read_holding_registers(
                address=start_address,
                count=count,
                slave=unit_id
            )
            
            if not result.isError():
                return result.registers
            else:
                logger.error(f"Error reading holding registers: {result}")
                return None
                
        except Exception as e:
            logger.error(f"Error reading from Modbus device {ip_address}: {e}")
            return None
    
    async def write_register(self, ip_address: str, address: int, 
                           value: int, unit_id: int = 1) -> bool:
        """Write single register to device"""
        if ip_address not in self.clients:
            logger.error(f"No connection to Modbus device {ip_address}")
            return False
        
        client = self.clients[ip_address]
        try:
            result = await client.write_register(
                address=address,
                value=value,
                slave=unit_id
            )
            
            if not result.isError():
                logger.info(f"Successfully wrote {value} to register {address}")
                return True
            else:
                logger.error(f"Error writing register: {result}")
                return False
                
        except Exception as e:
            logger.error(f"Error writing to Modbus device {ip_address}: {e}")
            return False
    
    async def read_float(self, ip_address: str, address: int, 
                        unit_id: int = 1) -> Optional[float]:
        """Read float value from two consecutive registers"""
        registers = await self.read_holding_registers(ip_address, address, 2, unit_id)
        
        if registers:
            decoder = BinaryPayloadDecoder.fromRegisters(
                registers,
                byteorder=Endian.BIG,
                wordorder=Endian.BIG
            )
            return decoder.decode_32bit_float()
        
        return None