# backend/app/modules/plc_communication/modbus_rtu.py
from pymodbus.client import AsyncModbusSerialClient
from pymodbus.constants import Endian
from pymodbus.payload import BinaryPayloadDecoder
from typing import Dict, List, Optional, Any
import asyncio
import logging
from datetime import datetime

from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

class ModbusRTUClient:
    def __init__(self):
        self.clients: Dict[str, AsyncModbusSerialClient] = {}
        self.is_running = False
    
    async def connect(self, device_config: dict) -> bool:
        """Connect to Modbus RTU device"""
        port = device_config["port"]
        baudrate = device_config.get("baudrate", settings.MODBUS_RTU_BAUDRATE)
        bytesize = device_config.get("bytesize", 8)
        parity = device_config.get("parity", "N")
        stopbits = device_config.get("stopbits", 1)
        
        try:
            client = AsyncModbusSerialClient(
                port=port,
                baudrate=baudrate,
                bytesize=bytesize,
                parity=parity,
                stopbits=stopbits,
                timeout=settings.PLC_TIMEOUT
            )
            
            await client.connect()
            
            if client.connected:
                self.clients[port] = client
                logger.info(f"Connected to Modbus RTU device on {port}")
                return True
            else:
                logger.error(f"Failed to connect to Modbus RTU device on {port}")
                return False
                
        except Exception as e:
            logger.error(f"Error connecting to Modbus RTU device {port}: {e}")
            return False
    
    async def disconnect(self, port: str):
        """Disconnect from Modbus RTU device"""
        if port in self.clients:
            try:
                await self.clients[port].close()
                del self.clients[port]
                logger.info(f"Disconnected from Modbus RTU device on {port}")
            except Exception as e:
                logger.error(f"Error disconnecting from Modbus RTU device {port}: {e}")
    
    async def read_holding_registers(self, port: str, slave_id: int,
                                   start_address: int, count: int) -> Optional[List[int]]:
        """Read holding registers from device"""
        if port not in self.clients:
            logger.error(f"No connection to Modbus RTU device on {port}")
            return None
        
        client = self.clients[port]
        try:
            result = await client.read_holding_registers(
                address=start_address,
                count=count,
                slave=slave_id
            )
            
            if not result.isError():
                return result.registers
            else:
                logger.error(f"Error reading holding registers: {result}")
                return None
                
        except Exception as e:
            logger.error(f"Error reading from Modbus RTU device on {port}: {e}")
            return None
    
    async def write_register(self, port: str, slave_id: int,
                           address: int, value: int) -> bool:
        """Write single register to device"""
        if port not in self.clients:
            logger.error(f"No connection to Modbus RTU device on {port}")
            return False
        
        client = self.clients[port]
        try:
            result = await client.write_register(
                address=address,
                value=value,
                slave=slave_id
            )
            
            if not result.isError():
                logger.info(f"Successfully wrote {value} to register {address}")
                return True
            else:
                logger.error(f"Error writing register: {result}")
                return False
                
        except Exception as e:
            logger.error(f"Error writing to Modbus RTU device on {port}: {e}")
            return False