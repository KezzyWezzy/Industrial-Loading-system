# backend/app/modules/plc_communication/tag_manager.py
from sqlalchemy.orm import Session
from typing import Dict, List, Optional, Any
import asyncio
import logging
from datetime import datetime
from decimal import Decimal

from app.core.database import get_db
from app.modules.websocket.connection_manager import connection_manager

logger = logging.getLogger(__name__)

class TagManager:
    def __init__(self):
        self.tag_values: Dict[str, Dict[str, Any]] = {}
        self.tag_configs: Dict[str, List[dict]] = {}
        self.subscribers: Dict[str, List[callable]] = {}
    
    async def configure_tags(self, plc_address: str, tags: List[dict]):
        """Configure tags for a PLC"""
        self.tag_configs[plc_address] = tags
        
        # Initialize tag values
        if plc_address not in self.tag_values:
            self.tag_values[plc_address] = {}
        
        for tag in tags:
            self.tag_values[plc_address][tag["name"]] = {
                "value": None,
                "quality": "Bad",
                "timestamp": datetime.utcnow()
            }
    
    async def update_tag_value(self, plc_address: str, tag_name: str, value: Any):
        """Update tag value and notify subscribers"""
        if plc_address not in self.tag_values:
            self.tag_values[plc_address] = {}
        
        old_value = self.tag_values[plc_address].get(tag_name, {}).get("value")
        
        self.tag_values[plc_address][tag_name] = {
            "value": value,
            "quality": "Good",
            "timestamp": datetime.utcnow()
        }
        
        # Notify subscribers if value changed
        if old_value != value:
            await self._notify_subscribers(plc_address, tag_name, value)
            
            # Send WebSocket update
            await connection_manager.publish_to_topic(
                f"plc_{plc_address}",
                {
                    "type": "tag_update",
                    "plc_address": plc_address,
                    "tag_name": tag_name,
                    "value": value,
                    "timestamp": datetime.utcnow().isoformat()
                }
            )
    
    async def get_tag_value(self, plc_address: str, tag_name: str) -> Optional[Any]:
        """Get current tag value"""
        return self.tag_values.get(plc_address, {}).get(tag_name, {}).get("value")
    
    async def get_tags_for_plc(self, plc_address: str) -> List[dict]:
        """Get configured tags for a PLC"""
        return self.tag_configs.get(plc_address, [])
    
    def subscribe_to_tag(self, plc_address: str, tag_name: str, callback: callable):
        """Subscribe to tag value changes"""
        key = f"{plc_address}:{tag_name}"
        if key not in self.subscribers:
            self.subscribers[key] = []
        self.subscribers[key].append(callback)
    
    async def _notify_subscribers(self, plc_address: str, tag_name: str, value: Any):
        """Notify all subscribers of tag value change"""
        key = f"{plc_address}:{tag_name}"
        if key in self.subscribers:
            for callback in self.subscribers[key]:
                try:
                    await callback(plc_address, tag_name, value)
                except Exception as e:
                    logger.error(f"Error notifying subscriber: {e}")
    
    def read_bay_tags(self, bay_tag_prefix: str) -> Dict[str, Any]:
        """Read all tags for a loading bay"""
        bay_tags = {}
        
        for plc_address, tags in self.tag_values.items():
            for tag_name, tag_data in tags.items():
                if tag_name.startswith(bay_tag_prefix):
                    # Extract tag suffix
                    suffix = tag_name[len(bay_tag_prefix):].lower()
                    
                    # Map common tag suffixes
                    if "flow" in suffix and "rate" in suffix:
                        bay_tags["flow_rate"] = tag_data["value"]
                    elif "pressure" in suffix:
                        bay_tags["pressure"] = tag_data["value"]
                    elif "temperature" in suffix:
                        bay_tags["temperature"] = tag_data["value"]
                    elif "volume" in suffix:
                        bay_tags["volume"] = tag_data["value"]
                    elif "valve" in suffix:
                        bay_tags["valve_state"] = tag_data["value"]
                    elif "pump" in suffix:
                        bay_tags["pump_state"] = tag_data["value"]
        
        return bay_tags