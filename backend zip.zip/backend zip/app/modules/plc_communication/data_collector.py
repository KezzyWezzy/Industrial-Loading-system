# backend/app/modules/plc_communication/data_collector.py
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any

from app.modules.plc_communication.ethernet_ip import EthernetIPClient
from app.modules.plc_communication.modbus_tcp import ModbusTCPClient
from app.modules.plc_communication.modbus_rtu import ModbusRTUClient
from app.modules.plc_communication.tag_manager import TagManager
from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

class DataCollector:
    def __init__(self):
        self.tag_manager = TagManager()
        self.ethernet_ip_client = EthernetIPClient(self.tag_manager)
        self.modbus_tcp_client = ModbusTCPClient()
        self.modbus_rtu_client = ModbusRTUClient()
        self.is_running = False
        self.collection_tasks = []
    
    async def start(self):
        """Start data collection from all configured devices"""
        self.is_running = True
        
        # Start Ethernet/IP polling
        ethernet_task = asyncio.create_task(self.ethernet_ip_client.start_polling())
        self.collection_tasks.append(ethernet_task)
        
        # Start Modbus TCP polling
        modbus_tcp_task = asyncio.create_task(self._poll_modbus_tcp_devices())
        self.collection_tasks.append(modbus_tcp_task)
        
        # Start Modbus RTU polling
        modbus_rtu_task = asyncio.create_task(self._poll_modbus_rtu_devices())
        self.collection_tasks.append(modbus_rtu_task)
        
        logger.info("Data collection started")
    
    async def stop(self):
        """Stop data collection"""
        self.is_running = False
        
        # Stop all clients
        await self.ethernet_ip_client.stop_polling()
        
        # Cancel all tasks
        for task in self.collection_tasks:
            task.cancel()
        
        # Wait for tasks to complete
        await asyncio.gather(*self.collection_tasks, return_exceptions=True)
        
        logger.info("Data collection stopped")
    
    async def _poll_modbus_tcp_devices(self):
        """Poll Modbus TCP devices"""
        while self.is_running:
            try:
                for ip_address, client in self.modbus_tcp_client.clients.items():
                    # Get device configuration
                    device_tags = await self.tag_manager.get_tags_for_plc(ip_address)
                    
                    for tag in device_tags:
                        if tag["type"] == "float":
                            value = await self.modbus_tcp_client.read_float(
                                ip_address,
                                tag["address"],
                                tag.get("unit_id", 1)
                            )
                            if value is not None:
                                await self.tag_manager.update_tag_value(
                                    ip_address,
                                    tag["name"],
                                    value
                                )
                
                await asyncio.sleep(settings.PLC_POLL_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error polling Modbus TCP devices: {e}")
                await asyncio.sleep(5)
    
    async def _poll_modbus_rtu_devices(self):
        """Poll Modbus RTU devices"""
        while self.is_running:
            try:
                for port, client in self.modbus_rtu_client.clients.items():
                    # Get device configuration
                    device_tags = await self.tag_manager.get_tags_for_plc(port)
                    
                    for tag in device_tags:
                        if tag["type"] == "registers":
                            values = await self.modbus_rtu_client.read_holding_registers(
                                port,
                                tag["slave_id"],
                                tag["address"],
                                tag["count"]
                            )
                            if values:
                                await self.tag_manager.update_tag_value(
                                    port,
                                    tag["name"],
                                    values
                                )
                
                await asyncio.sleep(settings.PLC_POLL_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error polling Modbus RTU devices: {e}")
                await asyncio.sleep(5)
    
    async def connect_plc(self, plc_config: dict) -> bool:
        """Connect to a PLC based on protocol type"""
        protocol = plc_config.get("protocol", "ethernet_ip")
        
        if protocol == "ethernet_ip":
            return await self.ethernet_ip_client.connect(plc_config)
        elif protocol == "modbus_tcp":
            return await self.modbus_tcp_client.connect(plc_config)
        elif protocol == "modbus_rtu":
            return await self.modbus_rtu_client.connect(plc_config)
        else:
            logger.error(f"Unknown protocol: {protocol}")
            return False
    
    async def disconnect_plc(self, address: str, protocol: str = "ethernet_ip"):
        """Disconnect from a PLC"""
        if protocol == "ethernet_ip":
            await self.ethernet_ip_client.disconnect(address)
        elif protocol == "modbus_tcp":
            await self.modbus_tcp_client.disconnect(address)
        elif protocol == "modbus_rtu":
            await self.modbus_rtu_client.disconnect(address)