# backend/app/modules/plc_communication/ethernet_ip.py
from pycomm3 import LogixDriver
from typing import Dict, List, Optional, Any
import asyncio
import logging
from datetime import datetime

from app.config.settings import get_settings
from app.modules.plc_communication.tag_manager import TagManager

logger = logging.getLogger(__name__)
settings = get_settings()

class EthernetIPClient:
    def __init__(self, tag_manager: TagManager):
        self.connections: Dict[str, LogixDriver] = {}
        self.tag_manager = tag_manager
        self.is_running = False
    
    async def connect(self, plc_config: dict) -> bool:
        """Connect to PLC via Ethernet/IP"""
        ip_address = plc_config["ip_address"]
        slot = plc_config.get("slot", 0)
        
        try:
            driver = LogixDriver(ip_address, slot=slot)
            driver.open()
            
            if driver.connected:
                self.connections[ip_address] = driver
                logger.info(f"Connected to PLC at {ip_address}")
                return True
            else:
                logger.error(f"Failed to connect to PLC at {ip_address}")
                return False
                
        except Exception as e:
            logger.error(f"Error connecting to PLC {ip_address}: {e}")
            return False
    
    async def disconnect(self, ip_address: str):
        """Disconnect from PLC"""
        if ip_address in self.connections:
            try:
                self.connections[ip_address].close()
                del self.connections[ip_address]
                logger.info(f"Disconnected from PLC at {ip_address}")
            except Exception as e:
                logger.error(f"Error disconnecting from PLC {ip_address}: {e}")
    
    async def read_tags(self, ip_address: str, tags: List[str]) -> Dict[str, Any]:
        """Read multiple tags from PLC"""
        if ip_address not in self.connections:
            logger.error(f"No connection to PLC {ip_address}")
            return {}
        
        driver = self.connections[ip_address]
        try:
            results = driver.read(*tags)
            if isinstance(results, list):
                return {tag: result.value for tag, result in zip(tags, results) if result.error is None}
            else:
                return {tags[0]: results.value} if results.error is None else {}
                
        except Exception as e:
            logger.error(f"Error reading tags from PLC {ip_address}: {e}")
            return {}
    
    async def write_tag(self, ip_address: str, tag: str, value: Any) -> bool:
        """Write value to PLC tag"""
        if ip_address not in self.connections:
            logger.error(f"No connection to PLC {ip_address}")
            return False
        
        driver = self.connections[ip_address]
        try:
            result = driver.write(tag, value)
            if result.error is None:
                logger.info(f"Successfully wrote {value} to {tag} on PLC {ip_address}")
                return True
            else:
                logger.error(f"Error writing to tag {tag}: {result.error}")
                return False
                
        except Exception as e:
            logger.error(f"Error writing to PLC {ip_address}: {e}")
            return False
    
    async def start_polling(self):
        """Start continuous polling of configured tags"""
        self.is_running = True
        
        while self.is_running:
            try:
                for ip_address, driver in self.connections.items():
                    if driver.connected:
                        # Get tags configured for this PLC
                        tags = await self.tag_manager.get_tags_for_plc(ip_address)
                        
                        if tags:
                            # Read all tags
                            tag_names = [tag.name for tag in tags]
                            values = await self.read_tags(ip_address, tag_names)
                            
                            # Update tag values in manager
                            for tag_name, value in values.items():
                                await self.tag_manager.update_tag_value(ip_address, tag_name, value)
                
                # Wait for poll interval
                await asyncio.sleep(settings.PLC_POLL_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error in polling loop: {e}")
                await asyncio.sleep(5)  # Wait before retrying
    
    async def stop_polling(self):
        """Stop polling loop"""
        self.is_running = False