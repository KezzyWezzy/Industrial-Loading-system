﻿from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db

router = APIRouter(prefix="/loading-bays", tags=["loading_bays"])

@router.get("/")
async def get_loading_bays(db: Session = Depends(get_db)):
    return {"message": "loading_bays system", "data": []}

@router.get("/health")
async def loading_bays_health():
    return {"status": "healthy", "module": "loading_bays"}
