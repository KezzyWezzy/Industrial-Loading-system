﻿from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db

router = APIRouter(prefix="/tanks", tags=["tanks"])

@router.get("/")
async def get_tanks(db: Session = Depends(get_db)):
    return {"message": "tanks system", "data": []}

@router.get("/health")
async def tanks_health():
    return {"status": "healthy", "module": "tanks"}
