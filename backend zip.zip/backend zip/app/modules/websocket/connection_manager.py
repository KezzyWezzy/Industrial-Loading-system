# backend/app/modules/websocket/connection_manager.py
from typing import Dict, List, Set, Optional, Any
from fastapi import WebSocket, WebSocketDisconnect
import json
import asyncio
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class ConnectionManager:
    def __init__(self):
        # Store active connections by client ID
        self.active_connections: Dict[str, WebSocket] = {}
        
        # Store topic subscriptions
        self.topic_subscriptions: Dict[str, Set[str]] = {}
        
        # Store client metadata
        self.client_metadata: Dict[str, Dict[str, Any]] = {}
        
        # Message queue for offline clients
        self.message_queue: Dict[str, List[Dict[str, Any]]] = {}
        
        # Lock for thread-safe operations
        self.lock = asyncio.Lock()
    
    async def connect(self, websocket: WebSocket, client_id: str, metadata: Optional[Dict[str, Any]] = None):
        """Accept new WebSocket connection"""
        await websocket.accept()
        
        async with self.lock:
            self.active_connections[client_id] = websocket
            self.client_metadata[client_id] = metadata or {}
            self.client_metadata[client_id]['connected_at'] = datetime.utcnow()
            
            # Send queued messages if any
            if client_id in self.message_queue:
                for message in self.message_queue[client_id]:
                    await self.send_personal_message(message, client_id)
                del self.message_queue[client_id]
        
        logger.info(f"Client {client_id} connected")
        
        # Send connection confirmation
        await self.send_personal_message({
            "type": "connection_established",
            "client_id": client_id,
            "timestamp": datetime.utcnow().isoformat()
        }, client_id)
    
    async def disconnect(self, client_id: str):
        """Remove WebSocket connection"""
        async with self.lock:
            if client_id in self.active_connections:
                del self.active_connections[client_id]
                
                # Remove from all topic subscriptions
                for topic, subscribers in self.topic_subscriptions.items():
                    subscribers.discard(client_id)
                
                # Clean up empty topics
                empty_topics = [topic for topic, subs in self.topic_subscriptions.items() if not subs]
                for topic in empty_topics:
                    del self.topic_subscriptions[topic]
                
                # Update metadata
                if client_id in self.client_metadata:
                    self.client_metadata[client_id]['disconnected_at'] = datetime.utcnow()
        
        logger.info(f"Client {client_id} disconnected")
    
    async def send_personal_message(self, message: Dict[str, Any], client_id: str):
        """Send message to specific client"""
        if client_id in self.active_connections:
            websocket = self.active_connections[client_id]
            try:
                await websocket.send_json(message)
            except Exception as e:
                logger.error(f"Error sending message to {client_id}: {e}")
                await self.disconnect(client_id)
        else:
            # Queue message for offline client
            if client_id not in self.message_queue:
                self.message_queue[client_id] = []
            self.message_queue[client_id].append(message)
    
    async def broadcast(self, message: Dict[str, Any]):
        """Broadcast message to all connected clients"""
        disconnected_clients = []
        
        for client_id, websocket in self.active_connections.items():
            try:
                await websocket.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to {client_id}: {e}")
                disconnected_clients.append(client_id)
        
        # Clean up disconnected clients
        for client_id in disconnected_clients:
            await self.disconnect(client_id)
    
    async def subscribe_to_topic(self, client_id: str, topic: str):
        """Subscribe client to a topic"""
        async with self.lock:
            if topic not in self.topic_subscriptions:
                self.topic_subscriptions[topic] = set()
            self.topic_subscriptions[topic].add(client_id)
        
        logger.info(f"Client {client_id} subscribed to topic {topic}")
        
        # Send subscription confirmation
        await self.send_personal_message({
            "type": "subscription_confirmed",
            "topic": topic,
            "timestamp": datetime.utcnow().isoformat()
        }, client_id)
    
    async def unsubscribe_from_topic(self, client_id: str, topic: str):
        """Unsubscribe client from a topic"""
        async with self.lock:
            if topic in self.topic_subscriptions:
                self.topic_subscriptions[topic].discard(client_id)
                
                # Clean up empty topic
                if not self.topic_subscriptions[topic]:
                    del self.topic_subscriptions[topic]
        
        logger.info(f"Client {client_id} unsubscribed from topic {topic}")
        
        # Send unsubscription confirmation
        await self.send_personal_message({
            "type": "unsubscription_confirmed",
            "topic": topic,
            "timestamp": datetime.utcnow().isoformat()
        }, client_id)
    
    async def publish_to_topic(self, topic: str, message: Dict[str, Any]):
        """Publish message to all subscribers of a topic"""
        if topic in self.topic_subscriptions:
            subscribers = self.topic_subscriptions[topic].copy()
            
            for client_id in subscribers:
                await self.send_personal_message({
                    "topic": topic,
                    **message
                }, client_id)
            
            logger.debug(f"Published message to {len(subscribers)} subscribers of topic {topic}")
    
    def get_active_connections(self) -> List[str]:
        """Get list of active client IDs"""
        return list(self.active_connections.keys())
    
    def get_client_info(self, client_id: str) -> Optional[Dict[str, Any]]:
        """Get client metadata"""
        return self.client_metadata.get(client_id)
    
    def get_topic_subscribers(self, topic: str) -> List[str]:
        """Get list of subscribers for a topic"""
        return list(self.topic_subscriptions.get(topic, set()))
    
    async def heartbeat(self):
        """Send heartbeat to all connected clients"""
        while True:
            await self.broadcast({
                "type": "heartbeat",
                "timestamp": datetime.utcnow().isoformat()
            })
            await asyncio.sleep(30)  # Send heartbeat every 30 seconds


# Global connection manager instance
connection_manager = ConnectionManager()


# backend/app/modules/websocket/handlers.py
from typing import Dict, Any, Optional
from fastapi import WebSocket, WebSocketDisconnect, Depends
from sqlalchemy.orm import Session
import json
import logging
import asyncio
from datetime import datetime

from app.core.database import get_db
from app.modules.websocket.connection_manager import connection_manager
from app.modules.websocket.events import WebSocketEventHandler
from app.modules.auth.dependencies import get_current_user_ws

logger = logging.getLogger(__name__)

class WebSocketHandler:
    def __init__(self):
        self.event_handler = WebSocketEventHandler()
    
    async def handle_connection(self, websocket: WebSocket, client_id: str, 
                               user_data: Optional[Dict[str, Any]] = None):
        """Handle WebSocket connection lifecycle"""
        # Accept connection
        await connection_manager.connect(websocket, client_id, user_data)
        
        try:
            # Subscribe to default topics based on user role
            if user_data:
                await self._subscribe_default_topics(client_id, user_data)
            
            # Handle messages
            while True:
                # Receive message
                data = await websocket.receive_text()
                
                try:
                    message = json.loads(data)
                    await self._handle_message(client_id, message)
                except json.JSONDecodeError:
                    await connection_manager.send_personal_message({
                        "type": "error",
                        "message": "Invalid JSON format"
                    }, client_id)
                except Exception as e:
                    logger.error(f"Error handling message from {client_id}: {e}")
                    await connection_manager.send_personal_message({
                        "type": "error",
                        "message": "Error processing message"
                    }, client_id)
        
        except WebSocketDisconnect:
            await connection_manager.disconnect(client_id)
        except Exception as e:
            logger.error(f"WebSocket error for {client_id}: {e}")
            await connection_manager.disconnect(client_id)
    
    async def _handle_message(self, client_id: str, message: Dict[str, Any]):
        """Route message to appropriate handler"""
        message_type = message.get("type")
        
        if message_type == "subscribe":
            topic = message.get("topic")
            if topic:
                await connection_manager.subscribe_to_topic(client_id, topic)
        
        elif message_type == "unsubscribe":
            topic = message.get("topic")
            if topic:
                await connection_manager.unsubscribe_from_topic(client_id, topic)
        
        elif message_type == "ping":
            await connection_manager.send_personal_message({
                "type": "pong",
                "timestamp": datetime.utcnow().isoformat()
            }, client_id)
        
        elif message_type == "get_status":
            entity_type = message.get("entity_type")
            entity_id = message.get("entity_id")
            
            if entity_type and entity_id:
                status = await self.event_handler.get_entity_status(entity_type, entity_id)
                await connection_manager.send_personal_message({
                    "type": "status_response",
                    "entity_type": entity_type,
                    "entity_id": entity_id,
                    "status": status
                }, client_id)
        
        else:
            # Handle custom message types
            await self.event_handler.handle_custom_event(client_id, message)
    
    async def _subscribe_default_topics(self, client_id: str, user_data: Dict[str, Any]):
        """Subscribe user to default topics based on role"""
        role = user_data.get("role", "operator")
        
        # Common topics for all users
        await connection_manager.subscribe_to_topic(client_id, "system_alerts")
        await connection_manager.subscribe_to_topic(client_id, "alarms")
        
        # Role-specific topics
        if role in ["supervisor", "manager"]:
            await connection_manager.subscribe_to_topic(client_id, "operations_overview")
            await connection_manager.subscribe_to_topic(client_id, "compliance_alerts")
        
        if role == "maintenance":
            await connection_manager.subscribe_to_topic(client_id, "equipment_status")
            await connection_manager.subscribe_to_topic(client_id, "maintenance_alerts")


# backend/app/modules/websocket/events.py
from typing import Dict, Any, Optional
from datetime import datetime
import logging
import asyncio

from app.modules.websocket.connection_manager import connection_manager
from app.core.database import get_db

logger = logging.getLogger(__name__)

class WebSocketEventHandler:
    """Handles business logic for WebSocket events"""
    
    async def handle_tank_update(self, tank_id: str, data: Dict[str, Any]):
        """Broadcast tank update to subscribers"""
        await connection_manager.publish_to_topic(
            f"tank_{tank_id}",
            {
                "type": "tank_update",
                "tank_id": tank_id,
                "data": data,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    
    async def handle_loading_bay_update(self, bay_id: str, data: Dict[str, Any]):
        """Broadcast loading bay update to subscribers"""
        await connection_manager.publish_to_topic(
            f"loading_bay_{bay_id}",
            {
                "type": "loading_bay_update",
                "bay_id": bay_id,
                "data": data,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    
    async def handle_transaction_update(self, transaction_id: str, data: Dict[str, Any]):
        """Broadcast transaction update to subscribers"""
        await connection_manager.publish_to_topic(
            f"transaction_{transaction_id}",
            {
                "type": "transaction_update",
                "transaction_id": transaction_id,
                "data": data,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
        # Also broadcast to operations overview
        await connection_manager.publish_to_topic(
            "operations_overview",
            {
                "type": "transaction_update",
                "transaction_id": transaction_id,
                "summary": {
                    "status": data.get("status"),
                    "bay_id": data.get("bay_id"),
                    "volume": data.get("volume")
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    
    async def handle_alarm_triggered(self, alarm_data: Dict[str, Any]):
        """Broadcast alarm to all subscribers"""
        await connection_manager.publish_to_topic(
            "alarms",
            {
                "type": "alarm_triggered",
                "alarm": alarm_data,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
        # Send to specific alarm priority topics
        priority = alarm_data.get("priority", "medium")
        if priority in ["critical", "high"]:
            await connection_manager.publish_to_topic(
                "critical_alarms",
                {
                    "type": "critical_alarm",
                    "alarm": alarm_data,
                    "timestamp": datetime.utcnow().isoformat()
                }
            )
    
    async def handle_equipment_status_change(self, equipment_id: str, status: str, details: Dict[str, Any]):
        """Broadcast equipment status change"""
        await connection_manager.publish_to_topic(
            f"equipment_{equipment_id}",
            {
                "type": "equipment_status_change",
                "equipment_id": equipment_id,
                "status": status,
                "details": details,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
        # Notify maintenance team
        if status in ["fault", "maintenance_required"]:
            await connection_manager.publish_to_topic(
                "maintenance_alerts",
                {
                    "type": "maintenance_alert",
                    "equipment_id": equipment_id,
                    "status": status,
                    "details": details,
                    "timestamp": datetime.utcnow().isoformat()
                }
            )
    
    async def handle_compliance_event(self, event_type: str, data: Dict[str, Any]):
        """Broadcast compliance-related events"""
        await connection_manager.publish_to_topic(
            "compliance_alerts",
            {
                "type": "compliance_event",
                "event_type": event_type,
                "data": data,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    
    async def handle_system_alert(self, alert_type: str, message: str, severity: str = "info"):
        """Broadcast system-wide alerts"""
        await connection_manager.broadcast({
            "type": "system_alert",
            "alert_type": alert_type,
            "message": message,
            "severity": severity,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    async def get_entity_status(self, entity_type: str, entity_id: str) -> Optional[Dict[str, Any]]:
        """Get current status of an entity"""
        # This would query the appropriate service based on entity type
        # For now, returning mock data
        
        if entity_type == "tank":
            return {
                "id": entity_id,
                "level": 15.5,
                "volume": 25000,
                "temperature": 75.2,
                "status": "normal"
            }
        elif entity_type == "loading_bay":
            return {
                "id": entity_id,
                "status": "idle",
                "last_transaction": None,
                "available": True
            }
        
        return None
    
    async def handle_custom_event(self, client_id: str, message: Dict[str, Any]):
        """Handle custom event types"""
        event_type = message.get("event_type")
        
        if event_type == "request_dashboard_data":
            # Send dashboard data to client
            dashboard_data = await self._get_dashboard_data()
            await connection_manager.send_personal_message({
                "type": "dashboard_data",
                "data": dashboard_data
            }, client_id)
        
        elif event_type == "request_notifications":
            # Send user notifications
            notifications = await self._get_user_notifications(client_id)
            await connection_manager.send_personal_message({
                "type": "notifications",
                "data": notifications
            }, client_id)
    
    async def _get_dashboard_data(self) -> Dict[str, Any]:
        """Get dashboard overview data"""
        # This would aggregate data from various services
        return {
            "tanks": {
                "total": 10,
                "active": 8,
                "alarms": 1
            },
            "loading_bays": {
                "total": 6,
                "available": 4,
                "loading": 2
            },
            "transactions": {
                "today": 15,
                "this_week": 87,
                "pending": 3
            }
        }
    
    async def _get_user_notifications(self, user_id: str) -> List[Dict[str, Any]]:
        """Get notifications for a user"""
        # This would query the notifications service
        return [
            {
                "id": "1",
                "type": "alarm",
                "message": "Tank T-001 high level alarm",
                "timestamp": datetime.utcnow().isoformat(),
                "read": False
            }
        ]


# backend/app/modules/websocket/__init__.py
from .connection_manager import ConnectionManager, connection_manager
from .handlers import WebSocketHandler
from .events import WebSocketEventHandler

__all__ = ['ConnectionManager', 'connection_manager', 'WebSocketHandler', 'WebSocketEventHandler']