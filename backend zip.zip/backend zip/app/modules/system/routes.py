﻿from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db

router = APIRouter(prefix="/system", tags=["system"])

@router.get("/")
async def get_system(db: Session = Depends(get_db)):
    return {"message": "system system", "data": []}

@router.get("/health")
async def system_health():
    return {"status": "healthy", "module": "system"}
