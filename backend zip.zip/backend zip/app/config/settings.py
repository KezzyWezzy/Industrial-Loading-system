﻿"""
Application settings configuration using dataclasses (no Pydantic)
"""
import os
from typing import List, Optional
from dataclasses import dataclass


@dataclass
class Settings:
    """Application settings using dataclasses"""
    
    # App settings
    app_name: str = "Industrial Loading System"
    app_version: str = "1.0.0"
    debug: bool = False
    
    # Environment settings
    ENVIRONMENT: str = "development"
    environment: str = "development"
    
    # Database settings
    database_url: str = "postgresql://postgres:password@localhost:5432/tank_management"
    DATABASE_URL: str = "postgresql://postgres:password@localhost:5432/tank_management"
    
    # Security settings
    secret_key: str = "your-secret-key-change-this-in-production"
    SECRET_KEY: str = "your-secret-key-change-this-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # CORS settings
    allowed_origins: List[str] = None
    ALLOWED_ORIGINS: List[str] = None
    
    # Tank management settings
    max_tanks: int = 100
    default_tank_capacity: float = 1000.0
    
    # PLC settings
    plc_host: str = "192.168.1.100"
    plc_port: int = 44818
    
    # Logging settings
    LOG_LEVEL: str = "INFO"
    log_level: str = "INFO"
    
    def __post_init__(self):
        """Load values from environment variables"""
        self.app_name = os.getenv("APP_NAME", self.app_name)
        self.app_version = os.getenv("APP_VERSION", self.app_version)
        self.debug = os.getenv("DEBUG", "false").lower() in ("true", "1", "yes")
        
        self.ENVIRONMENT = os.getenv("ENVIRONMENT", self.ENVIRONMENT)
        self.environment = self.ENVIRONMENT.lower()
        
        self.database_url = os.getenv("DATABASE_URL", self.database_url)
        self.DATABASE_URL = self.database_url
        
        self.secret_key = os.getenv("SECRET_KEY", self.secret_key)
        self.SECRET_KEY = self.secret_key
        self.algorithm = os.getenv("ALGORITHM", self.algorithm)
        self.access_token_expire_minutes = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", str(self.access_token_expire_minutes)))
        
        if self.allowed_origins is None:
            self.allowed_origins = ["http://localhost:3000", "http://127.0.0.1:3000"]
        
        origins_env = os.getenv("ALLOWED_ORIGINS")
        if origins_env:
            self.allowed_origins = [origin.strip() for origin in origins_env.split(",")]
        
        self.ALLOWED_ORIGINS = self.allowed_origins
        
        self.max_tanks = int(os.getenv("MAX_TANKS", str(self.max_tanks)))
        self.default_tank_capacity = float(os.getenv("DEFAULT_TANK_CAPACITY", str(self.default_tank_capacity)))
        
        self.plc_host = os.getenv("PLC_HOST", self.plc_host)
        self.plc_port = int(os.getenv("PLC_PORT", str(self.plc_port)))
        
        self.LOG_LEVEL = os.getenv("LOG_LEVEL", self.LOG_LEVEL)
        self.log_level = self.LOG_LEVEL.lower()


_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get application settings (singleton pattern)"""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
