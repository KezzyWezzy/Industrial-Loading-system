# backend/app/config/database.py
# This file is now integrated into app/core/database.py
# Keeping for backward compatibility
from app.core.database import *
