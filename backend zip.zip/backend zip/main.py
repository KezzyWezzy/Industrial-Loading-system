# backend/app/main.py
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.config.settings import get_settings
from app.core.database import engine, Base
from app.modules.plc_communication.data_collector import DataCollector

# Import routers
from app.modules.auth.routes import router as auth_router
from app.modules.facilities.routes import router as facilities_router
from app.modules.tanks.routes import router as tanks_router
from app.modules.loading_bays.routes import router as loading_bays_router
from app.modules.websocket.handlers import WebSocketHandler

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

settings = get_settings()

# Initialize data collector
data_collector = DataCollector()
websocket_handler = WebSocketHandler()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    # Startup
    logger.info("Starting Industrial Loading System...")
    
    # Create database tables
    Base.metadata.create_all(bind=engine)
    
    # Start data collection
    await data_collector.start()
    
    yield
    
    # Shutdown
    logger.info("Shutting down Industrial Loading System...")
    await data_collector.stop()

# Create FastAPI app
app = FastAPI(
    title="Industrial Loading System API",
    description="API for industrial tank, rail cart, truck, and barge loading operations",
    version="1.0.0",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # React frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_router, prefix="/api/auth", tags=["Authentication"])
app.include_router(facilities_router, prefix="/api/facilities", tags=["Facilities"])
app.include_router(tanks_router, prefix="/api/tanks", tags=["Tanks"])
app.include_router(loading_bays_router, prefix="/api/loading-bays", tags=["Loading Bays"])

# Health check endpoint
@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Industrial Loading System",
        "version": "1.0.0"
    }

# WebSocket endpoint
@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    """WebSocket endpoint for real-time updates"""
    from app.core.database import SessionLocal
    
    db = SessionLocal()
    try:
        await websocket_handler.handle_connection(websocket, client_id, db)
    finally:
        db.close()

# Root endpoint
@app.get("/")
def read_root():
    """Root endpoint"""
    return {
        "message": "Industrial Loading System API",
        "documentation": "/docs",
        "health": "/health"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)