# Environment configuration for Tank Management System
# Copy this to .env and adjust values as needed

# Environment settings
ENVIRONMENT=development
# Options: development, production, testing

# App settings
APP_NAME="Industrial Loading System"
APP_VERSION="1.0.0"
DEBUG=true
TESTING=false

# Database settings
DATABASE_URL="postgresql://postgres:password@localhost:5432/tank_management"
# Or use individual components:
DB_HOST=localhost
DB_PORT=5432
DB_NAME=tank_management
DB_USER=postgres
DB_PASSWORD=password

# Security settings (CHANGE THESE IN PRODUCTION!)
SECRET_KEY="your-very-secure-secret-key-change-this-in-production"
ALGORITHM="HS256"
ACCESS_TOKEN_EXPIRE_MINUTES=30

# CORS settings
ALLOWED_ORIGINS="http://localhost:3000,http://127.0.0.1:3000"

# Tank management settings
MAX_TANKS=100
DEFAULT_TANK_CAPACITY=1000.0

# Industrial system settings
PLC_HOST=192.168.1.100
PLC_PORT=44818

# Logging
LOG_LEVEL=INFO