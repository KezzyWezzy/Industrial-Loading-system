# Complete FastAPI Industrial Loading System Backend Setup Script
# Run this script from your backend directory

Write-Host "Creating Industrial Loading System Backend Structure..." -ForegroundColor Green

# Create directory structure
$directories = @(
    "app",
    "app\config",
    "app\core", 
    "app\modules",
    "app\modules\auth",
    "app\modules\tanks",
    "app\modules\loading_bays",
    "app\modules\transactions", 
    "app\modules\facilities",
    "app\modules\reporting",
    "app\modules\system",
    "alembic",
    "alembic\versions"
)

foreach ($dir in $directories) {
    if (!(Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force
        Write-Host "Created directory: $dir" -ForegroundColor Yellow
    }
}

# Create __init__.py files
$initFiles = @(
    "app\__init__.py",
    "app\config\__init__.py", 
    "app\core\__init__.py",
    "app\modules\__init__.py",
    "app\modules\auth\__init__.py",
    "app\modules\tanks\__init__.py",
    "app\modules\loading_bays\__init__.py",
    "app\modules\transactions\__init__.py",
    "app\modules\facilities\__init__.py",
    "app\modules\reporting\__init__.py",
    "app\modules\system\__init__.py"
)

foreach ($file in $initFiles) {
    Set-Content -Path $file -Value '"""Package initialization"""' -Encoding UTF8
}

# Create app/config/settings.py
$settingsContent = @'
"""
Application settings configuration using dataclasses (no Pydantic)
"""
import os
from typing import List, Optional
from dataclasses import dataclass


@dataclass
class Settings:
    """Application settings using dataclasses"""
    
    # App settings
    app_name: str = "Industrial Loading System"
    app_version: str = "1.0.0"
    debug: bool = False
    
    # Environment settings
    ENVIRONMENT: str = "development"
    environment: str = "development"
    
    # Database settings
    database_url: str = "postgresql://postgres:password@localhost:5432/tank_management"
    DATABASE_URL: str = "postgresql://postgres:password@localhost:5432/tank_management"
    
    # Security settings
    secret_key: str = "your-secret-key-change-this-in-production"
    SECRET_KEY: str = "your-secret-key-change-this-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # CORS settings
    allowed_origins: List[str] = None
    ALLOWED_ORIGINS: List[str] = None
    
    # Tank management settings
    max_tanks: int = 100
    default_tank_capacity: float = 1000.0
    
    # PLC settings
    plc_host: str = "192.168.1.100"
    plc_port: int = 44818
    
    # Logging settings
    LOG_LEVEL: str = "INFO"
    log_level: str = "INFO"
    
    def __post_init__(self):
        """Load values from environment variables"""
        self.app_name = os.getenv("APP_NAME", self.app_name)
        self.app_version = os.getenv("APP_VERSION", self.app_version)
        self.debug = os.getenv("DEBUG", "false").lower() in ("true", "1", "yes")
        
        self.ENVIRONMENT = os.getenv("ENVIRONMENT", self.ENVIRONMENT)
        self.environment = self.ENVIRONMENT.lower()
        
        self.database_url = os.getenv("DATABASE_URL", self.database_url)
        self.DATABASE_URL = self.database_url
        
        self.secret_key = os.getenv("SECRET_KEY", self.secret_key)
        self.SECRET_KEY = self.secret_key
        self.algorithm = os.getenv("ALGORITHM", self.algorithm)
        self.access_token_expire_minutes = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", str(self.access_token_expire_minutes)))
        
        if self.allowed_origins is None:
            self.allowed_origins = ["http://localhost:3000", "http://127.0.0.1:3000"]
        
        origins_env = os.getenv("ALLOWED_ORIGINS")
        if origins_env:
            self.allowed_origins = [origin.strip() for origin in origins_env.split(",")]
        
        self.ALLOWED_ORIGINS = self.allowed_origins
        
        self.max_tanks = int(os.getenv("MAX_TANKS", str(self.max_tanks)))
        self.default_tank_capacity = float(os.getenv("DEFAULT_TANK_CAPACITY", str(self.default_tank_capacity)))
        
        self.plc_host = os.getenv("PLC_HOST", self.plc_host)
        self.plc_port = int(os.getenv("PLC_PORT", str(self.plc_port)))
        
        self.LOG_LEVEL = os.getenv("LOG_LEVEL", self.LOG_LEVEL)
        self.log_level = self.LOG_LEVEL.lower()


_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get application settings (singleton pattern)"""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
'@

Set-Content -Path "app\config\settings.py" -Value $settingsContent -Encoding UTF8

# Create app/core/database.py
$databaseContent = @'
"""
Database configuration and shared base class
"""
from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.config.settings import get_settings
import logging

# Get settings
settings = get_settings()

# Configure logging
logging.basicConfig(level=getattr(logging, settings.LOG_LEVEL.upper()))
logger = logging.getLogger(__name__)

# SHARED BASE CLASS - All models should import this Base
Base = declarative_base()

# Database configuration
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    echo=settings.debug
)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """Database session dependency"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Initialize database - create all tables"""
    try:
        # Import all models to register them
        from app.modules.auth.models import User, AuditLog, UserSession, Role, Permission
        from app.modules.facilities.models import Facility, Product, Customer, Carrier
        
        # Create all tables
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
        return True
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        return False


def check_database_connection():
    """Check database connection"""
    try:
        with engine.connect() as connection:
            result = connection.execute("SELECT 1")
            result.fetchone()
        logger.info("Database connection successful")
        return True
    except Exception as e:
        logger.error(f"Database connection failed: {e}")
        return False
'@

Set-Content -Path "app\core\database.py" -Value $databaseContent -Encoding UTF8

# Create app/modules/auth/models.py
$authModelsContent = @'
"""
Authentication models for the industrial loading system
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from typing import Optional

# Import shared Base class
from app.core.database import Base


class User(Base):
    """User model for authentication"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    
    failed_login_attempts = Column(Integer, default=0)
    last_login = Column(DateTime(timezone=True), nullable=True)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    def __repr__(self):
        return f"<User(username='{self.username}')>"


class Role(Base):
    """Role model for role-based access control"""
    __tablename__ = "roles"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class Permission(Base):
    """Permission model for granular access control"""
    __tablename__ = "permissions"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    resource = Column(String(50), nullable=False)
    action = Column(String(50), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class UserSession(Base):
    """User session model for tracking active sessions"""
    __tablename__ = "user_sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    session_token = Column(String(255), unique=True, index=True, nullable=False)
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    last_activity = Column(DateTime(timezone=True), server_default=func.now())
    user = relationship("User")


class AuditLog(Base):
    """Audit log model for tracking user actions"""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(100), nullable=False)
    resource = Column(String(100), nullable=True)
    ip_address = Column(String(45), nullable=True)
    details = Column(Text, nullable=True)
    success = Column(Boolean, default=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    user = relationship("User")
'@

Set-Content -Path "app\modules\auth\models.py" -Value $authModelsContent -Encoding UTF8

# Create auth service
$authServiceContent = @'
"""
Authentication service for the industrial loading system
"""
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime


class AuthService:
    """Service class for authentication operations"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def authenticate_user(self, username: str, password: str):
        """Authenticate user credentials"""
        return {"user_id": 1, "username": username, "authenticated": True}
    
    def create_user(self, user_data: Dict[str, Any]):
        """Create a new user"""
        return {"id": 1, "username": user_data.get("username"), "status": "created"}
    
    def get_user_by_id(self, user_id: int):
        """Get user by ID"""
        return {"id": user_id, "username": "demo_user", "email": "demo@example.com"}
'@

Set-Content -Path "app\modules\auth\service.py" -Value $authServiceContent -Encoding UTF8

# Create auth routes
$authRoutesContent = @'
"""
Authentication routes for the industrial loading system
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional

from app.core.database import get_db
from app.modules.auth.service import AuthService
from app.modules.auth.models import User, Role, Permission, UserSession

router = APIRouter(prefix="/auth", tags=["authentication"])


@router.get("/")
async def auth_status():
    """Authentication system status"""
    return {"message": "Authentication system", "status": "operational"}


@router.get("/health")
async def auth_health():
    """Authentication health check"""
    return {"status": "healthy", "module": "auth"}


@router.post("/login")
async def login(username: str, password: str, db: Session = Depends(get_db)):
    """User login endpoint"""
    service = AuthService(db)
    result = service.authenticate_user(username, password)
    return {"message": "Login successful", "user": result}


@router.get("/users")
async def get_users(db: Session = Depends(get_db)):
    """Get all users"""
    return {"users": [{"id": 1, "username": "admin", "email": "admin@example.com"}]}
'@

Set-Content -Path "app\modules\auth\routes.py" -Value $authRoutesContent -Encoding UTF8

# Create facilities models
$facilitiesModelsContent = @'
"""
Facilities models for the industrial loading system
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.core.database import Base


class Facility(Base):
    """Facility model for industrial loading facilities"""
    __tablename__ = "facilities"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, index=True)
    code = Column(String(20), unique=True, nullable=False, index=True)
    address = Column(Text, nullable=True)
    city = Column(String(50), nullable=True)
    capacity = Column(Float, nullable=True)
    is_active = Column(Boolean, default=True)
    facility_type = Column(String(50), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class Product(Base):
    """Product model for materials being handled"""
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)
    density = Column(Float, nullable=True)
    safety_category = Column(String(20), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Customer(Base):
    """Customer model"""
    __tablename__ = "customers"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, index=True)
    code = Column(String(20), unique=True, nullable=False, index=True)
    contact_person = Column(String(100), nullable=True)
    email = Column(String(255), nullable=True)
    phone = Column(String(20), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Carrier(Base):
    """Carrier model for transportation companies"""
    __tablename__ = "carriers"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, index=True)
    code = Column(String(20), unique=True, nullable=False, index=True)
    contact_person = Column(String(100), nullable=True)
    license_number = Column(String(50), nullable=True)
    is_active = Column(Boolean, default=True)
    is_approved = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
'@

Set-Content -Path "app\modules\facilities\models.py" -Value $facilitiesModelsContent -Encoding UTF8

# Create facilities routes
$facilitiesRoutesContent = @'
"""
Facilities routes for the industrial loading system
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.database import get_db

router = APIRouter(prefix="/facilities", tags=["facilities"])


@router.get("/")
async def get_facilities(db: Session = Depends(get_db)):
    """Get all facilities"""
    return {"facilities": [{"id": 1, "name": "Main Loading Facility", "code": "MLF001"}]}


@router.get("/health")
async def facilities_health():
    """Facilities health check"""
    return {"status": "healthy", "module": "facilities"}
'@

Set-Content -Path "app\modules\facilities\routes.py" -Value $facilitiesRoutesContent -Encoding UTF8

# Create all other module files
$modules = @("tanks", "loading_bays", "transactions", "reporting", "system")

foreach ($module in $modules) {
    # Create service
    $serviceContent = @"
from sqlalchemy.orm import Session

class $($module.ToTitleCase())Service:
    def __init__(self, db: Session):
        self.db = db
    
    def get_all(self):
        return []
"@
    
    # Create routes
    $routeContent = @"
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db

router = APIRouter(prefix="/$($module.Replace('_', '-'))", tags=["$module"])

@router.get("/")
async def get_$module(db: Session = Depends(get_db)):
    return {"message": "$module system", "data": []}

@router.get("/health")
async def $($module)_health():
    return {"status": "healthy", "module": "$module"}
"@

    Set-Content -Path "app\modules\$module\service.py" -Value $serviceContent -Encoding UTF8
    Set-Content -Path "app\modules\$module\routes.py" -Value $routeContent -Encoding UTF8
}

# Create main.py
$mainContent = @'
"""
Main FastAPI application for Industrial Loading System
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config.settings import get_settings
from app.core.database import init_db, check_database_connection

# Import routers
from app.modules.auth.routes import router as auth_router
from app.modules.tanks.routes import router as tanks_router
from app.modules.loading_bays.routes import router as loading_bays_router
from app.modules.transactions.routes import router as transactions_router
from app.modules.facilities.routes import router as facilities_router
from app.modules.reporting.routes import router as reporting_router
from app.modules.system.routes import router as system_router

# Get settings
settings = get_settings()

# Create FastAPI app
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Industrial Loading System API"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_router)
app.include_router(tanks_router)
app.include_router(loading_bays_router)
app.include_router(transactions_router)
app.include_router(facilities_router)
app.include_router(reporting_router)
app.include_router(system_router)


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Industrial Loading System API",
        "version": settings.app_version,
        "status": "operational"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    db_healthy = check_database_connection()
    return {
        "status": "healthy" if db_healthy else "unhealthy",
        "database": "connected" if db_healthy else "disconnected",
        "version": settings.app_version
    }


@app.on_event("startup")
async def startup_event():
    """Application startup"""
    print(f"Starting {settings.app_name} v{settings.app_version}")
    if settings.ENVIRONMENT == "development":
        init_db()
'@

Set-Content -Path "app\main.py" -Value $mainContent -Encoding UTF8

# Create .env file
$envContent = @'
# Environment configuration for Industrial Loading System

# Environment
ENVIRONMENT=development
DEBUG=true

# Database
DATABASE_URL=postgresql://postgres:password@localhost:5432/tank_management

# Security (CHANGE IN PRODUCTION!)
SECRET_KEY=your-very-secure-secret-key-change-this-in-production

# CORS
ALLOWED_ORIGINS=http://localhost:3000,http://127.0.0.1:3000

# Application
APP_NAME=Industrial Loading System
LOG_LEVEL=INFO
'@

Set-Content -Path ".env" -Value $envContent -Encoding UTF8

# Create requirements.txt
$requirementsContent = @'
# Core FastAPI dependencies
fastapi>=0.104.0
uvicorn[standard]>=0.24.0
python-multipart>=0.0.6

# Database
sqlalchemy>=2.0.0
psycopg2-binary>=2.9.0
alembic>=1.12.0

# Authentication & Security
PyJWT>=2.8.0
python-jose[cryptography]>=3.3.0
passlib[bcrypt]>=1.7.4
pyotp>=2.9.0
email-validator>=2.0.0

# Environment
python-dotenv>=1.0.0

# Industrial protocols
pycomm3>=1.2.0
pymodbus>=3.5.0

# Utilities
aiofiles>=23.2.0
pandas>=2.1.0
typing-extensions>=4.8.0
'@

Set-Content -Path "requirements.txt" -Value $requirementsContent -Encoding UTF8

# Create alembic.ini
$alembicIniContent = @'
[alembic]
script_location = alembic
prepend_sys_path = .
version_path_separator = os
sqlalchemy.url = postgresql://postgres:password@localhost:5432/tank_management

[post_write_hooks]

[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level = WARN
handlers = console
qualname =

[logger_sqlalchemy]
level = WARN
handlers =
qualname = sqlalchemy.engine

[logger_alembic]
level = INFO
handlers =
qualname = alembic

[handler_console]
class = StreamHandler
args = (sys.stderr,)
level = NOTSET
formatter = generic

[formatter_generic]
format = %(levelname)-5.5s [%(name)s] %(message)s
datefmt = %H:%M:%S
'@

Set-Content -Path "alembic.ini" -Value $alembicIniContent -Encoding UTF8

Write-Host "✅ Backend structure created successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Install dependencies: pip install -r requirements.txt" -ForegroundColor White
Write-Host "2. Update database connection in .env file" -ForegroundColor White  
Write-Host "3. Run the application: uvicorn app.main:app --reload" -ForegroundColor White
Write-Host ""
Write-Host "🚀 Your Industrial Loading System backend is ready!" -ForegroundColor Green